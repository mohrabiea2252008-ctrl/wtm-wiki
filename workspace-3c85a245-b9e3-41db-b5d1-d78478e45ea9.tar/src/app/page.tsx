'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Search, Filter, Star, Shield, Target, Zap, Play, ArrowRight, RotateCcw } from 'lucide-react'

interface Tank {
  id: string
  name: string
  tier: string
  type: string
  nation: string
  status: string
  ammoType: string[]
  playstyle: {
    name: string
    description: string
    howTo: string[]
  }
  weakspots: string[]
  description: string
  armor: {
    front: number
    side: number
    rear: number
  }
  firepower: {
    damage: number
    penetration: number
    rateOfFire: number
  }
  mobility: {
    speed: number
    reverseSpeed: number
    powerToWeight: number
  }
  special?: string
  image?: string
}

const tanksData: Tank[] = [
  {
    id: 'm4a1-76-w',
    name: 'M4A1 (76) W',
    tier: 'Tier V',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Premium',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'Hit & Run',
      description: 'Strike quickly from cover, deal damage, then retreat before enemies can retaliate',
      howTo: [
        'Use ridges and buildings for peek-a-boo attacks',
        'Fire 2-3 shots then immediately reverse to cover',
        'Target enemy sides and rear for maximum damage',
        'Keep moving to avoid being an easy target',
        'Use speed to reposition after each engagement'
      ]
    },
    weakspots: ['Lower glacis (51mm at 47°)', 'Turret cheeks', 'Side hull (38mm)', 'Mantlet edges'],
    description: 'American medium tank with 76mm gun. Balanced firepower and mobility for aggressive play.',
    armor: { front: 63, side: 38, rear: 38 },
    firepower: { damage: 115, penetration: 128, rateOfFire: 7.5 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.5 },
    special: '2024 winter event camo available for 500 GE',
    image: '/tanks/m4a1-76-w.png'
  },
  {
    id: 'pziv-f2',
    name: 'Pz.IV F2',
    tier: 'Tier III',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Standard',
    ammoType: ['PzGr.39 APCBC', 'PzGr.40 APCR', 'Gr.38 HL HEAT', 'Sprgr.34 HE'],
    playstyle: {
      name: 'Long Range Sniper',
      description: 'Stay at maximum distance and pick off enemies with superior accuracy',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at 600-800m for best accuracy',
        'Use bushes and terrain for concealment',
        'Aim for enemy weakspots: lower glacis and turret cheeks',
        'Relocate after every 3-4 shots to avoid counter-fire'
      ]
    },
    weakspots: ['Turret front (50mm)', 'Hull sides (30mm)', 'Lower glacis (50mm at 10°)', 'Gun mantlet'],
    description: 'German medium tank with excellent 75mm L/43 gun for long-range combat.',
    armor: { front: 50, side: 30, rear: 20 },
    firepower: { damage: 110, penetration: 98, rateOfFire: 8.5 },
    mobility: { speed: 42, reverseSpeed: 18, powerToWeight: 12.8 },
    image: '/tanks/pziv-f2.png'
  },
  {
    id: 'pziv-f2-outdated',
    name: 'Pz.IV F2 (outdated)',
    tier: 'Tier III',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Outdated',
    ammoType: ['PzGr.39 APCBC', 'PzGr.40 APCR', 'Gr.38 HL HEAT', 'Sprgr.34 HE'],
    playstyle: {
      name: 'Support Fire',
      description: 'Provide accurate fire support while maintaining safe distance',
      howTo: [
        'Position behind friendly heavy tanks',
        'Focus on enemy medium and light tanks',
        'Use APCR for heavily armored targets',
        'Maintain distance to compensate for weaker stats',
        'Assist flanking maneuvers with covering fire'
      ]
    },
    weakspots: ['Turret front (50mm)', 'Hull sides (30mm)', 'Lower glacis (50mm at 10°)', 'Gun mantlet'],
    description: 'Older Pz.IV F2 version with reduced performance characteristics.',
    armor: { front: 50, side: 30, rear: 20 },
    firepower: { damage: 110, penetration: 98, rateOfFire: 8.5 },
    mobility: { speed: 42, reverseSpeed: 18, powerToWeight: 12.8 },
    image: '/tanks/pziv-f2-outdated.png'
  },
  {
    id: 'pziv-g',
    name: 'Pz.IV G',
    tier: 'Tier IV',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Standard',
    ammoType: ['PzGr.39 APCBC', 'PzGr.40 APCR', 'Gr.38 HL HEAT', 'Sprgr.34 HE'],
    playstyle: {
      name: 'Flanking Harasser',
      description: 'Use mobility to attack enemy sides and create confusion',
      howTo: [
        'Circle around enemy formations to find weak spots',
        'Target enemy artillery and TDs first',
        'Use speed to escape when targeted by multiple enemies',
        'Coordinate with team for synchronized attacks',
        'Never engage in head-on fights with heavy tanks'
      ]
    },
    weakspots: ['Turret face (50mm curved)', 'Hull sides (30mm)', 'Lower front (80mm at 10°)', 'Commander cupola'],
    description: 'Improved Pz.IV with longer 75mm L/48 gun and better frontal armor.',
    armor: { front: 80, side: 30, rear: 20 },
    firepower: { damage: 120, penetration: 106, rateOfFire: 8.0 },
    mobility: { speed: 40, reverseSpeed: 18, powerToWeight: 11.5 },
    image: '/tanks/pziv-g.png'
  },
  {
    id: 'pziv-g-outdated',
    name: 'Pz.IV G (outdated)',
    tier: 'Tier IV',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Outdated',
    ammoType: ['PzGr.39 APCBC', 'PzGr.40 APCR', 'Gr.38 HL HEAT', 'Sprgr.34 HE'],
    playstyle: {
      name: 'Defensive Support',
      description: 'Hold key positions and provide accurate fire support',
      howTo: [
        'Position near capture points to defend them',
        'Use terrain to maximize frontal armor effectiveness',
        'Prioritize enemies threatening capture points',
        'Fall back to secondary positions when overwhelmed',
        'Provide covering fire for retreating teammates'
      ]
    },
    weakspots: ['Turret face (50mm curved)', 'Hull sides (30mm)', 'Lower front (80mm at 10°)', 'Commander cupola'],
    description: 'Older Pz.IV G version with reduced performance characteristics.',
    armor: { front: 80, side: 30, rear: 20 },
    firepower: { damage: 120, penetration: 106, rateOfFire: 8.0 },
    mobility: { speed: 40, reverseSpeed: 18, powerToWeight: 11.5 },
    image: '/tanks/pziv-g-outdated.png'
  },
  {
    id: 'stug-iii-f',
    name: 'StuG III F',
    tier: 'Tier III',
    type: 'Tank Destroyer',
    nation: 'Germany',
    status: 'Standard',
    ammoType: ['PzGr.39 APCBC', 'PzGr.40 APCR', 'Gr.38 HL HEAT', 'Sprgr.34 HE'],
    playstyle: {
      name: 'Ambush Predator',
      description: 'Conceal yourself and destroy enemies before they can react',
      howTo: [
        'Find bushes or destroyed buildings for cover',
        'Wait for enemies to expose their weak sides',
        'Fire first shot for maximum damage bonus',
        'Immediately relocate after firing to avoid detection',
        'Target high-value enemies: heavy tanks and SPGs'
      ]
    },
    weakspots: ['Superstructure front (50mm)', 'Lower hull (50mm at 21°)', 'Side armor (30mm)', 'Gun mantlet edges'],
    description: 'German TD with excellent 75mm L/43 gun and low profile for ambush tactics.',
    armor: { front: 50, side: 30, rear: 30 },
    firepower: { damage: 110, penetration: 98, rateOfFire: 8.5 },
    mobility: { speed: 40, reverseSpeed: 18, powerToWeight: 13.2 },
    image: '/tanks/stug-iii-f.png'
  },
  {
    id: 'm4a1',
    name: 'M4A1',
    tier: 'Tier IV',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Standard',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'All-Rounder',
      description: 'Adapt to any combat situation with balanced performance',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play as needed',
        'Exploit enemy mistakes with quick counter-attacks'
      ]
    },
    weakspots: ['Turret cheeks (63mm)', 'Lower glacis (51mm at 47°)', 'Side hull (38mm)', 'Mantlet edges'],
    description: 'American medium tank with cast hull and 75mm gun. Reliable and balanced.',
    armor: { front: 51, side: 38, rear: 38 },
    firepower: { damage: 110, penetration: 92, rateOfFire: 8.0 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 14.5 },
    image: '/tanks/m4a1.png'
  },
  {
    id: 't34-1940',
    name: 'T34 (1940)',
    tier: 'Tier IV',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Standard',
    ammoType: ['BR-350A APBC', 'BR-350P APCR', 'F-354 HE'],
    playstyle: {
      name: 'Corner Brawler',
      description: 'Use angled armor in close-quarters combat to bounce enemy shells',
      howTo: [
        'Position near corners and buildings for cover',
        'Angle hull at 30-45° to maximize armor effectiveness',
        'Side-scrape to expose only your strong turret',
        'Push corners aggressively to force enemies back',
        'Use HE to destroy cover and flush out enemies'
      ]
    },
    weakspots: ['Turret ring', 'Lower glacis (45mm at 60°)', 'Side armor (45mm)', 'Rear armor'],
    description: 'Soviet heavy tank with angled armor design and 76mm gun.',
    armor: { front: 45, side: 45, rear: 40 },
    firepower: { damage: 110, penetration: 78, rateOfFire: 7.0 },
    mobility: { speed: 34, reverseSpeed: 15, powerToWeight: 11.8 },
    image: '/tanks/t34-1940.png'
  },
  {
    id: 'kv2-premium',
    name: 'KV-2 (premium)',
    tier: 'Tier V',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Premium',
    ammoType: ['OF-530 HE', 'BR-350A APBC', 'BR-350P APCR'],
    playstyle: {
      name: 'HE Terror',
      description: 'Devastate enemies with massive high-explosive shells',
      howTo: [
        'Load HE shells and aim for enemy centers',
        'Target groups of enemies for area damage',
        'Use HE to destroy enemy cover and fortifications',
        'Switch to AP when facing heavily armored targets',
        'Exploit chaos created by HE bombardment'
      ]
    },
    weakspots: ['Large turret', 'Side armor (60mm)', 'Lower hull', 'Slow traverse'],
    description: 'Soviet heavy tank with massive 152mm howitzer. Devastating HE damage.',
    armor: { front: 75, side: 60, rear: 60 },
    firepower: { damage: 910, penetration: 90, rateOfFire: 3.5 },
    mobility: { speed: 26, reverseSpeed: 12, powerToWeight: 10.2 },
    image: '/tanks/kv2-premium.png'
  },
  {
    id: 'm4a4-alpha',
    name: 'M4A4 (alpha test reward)',
    tier: 'Tier V',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Collectible',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'Elite Flanker',
      description: 'Use superior mobility to outmaneuver and outshoot enemies',
      howTo: [
        'Use speed to get to key positions first',
        'Flank enemy formations to attack weak sides',
        'Pick off isolated enemies with accurate fire',
        'Coordinate with team for synchronized attacks',
        'Use hit-and-run tactics against heavy tanks'
      ]
    },
    weakspots: ['Turret cheeks', 'Lower glacis', 'Side hull', 'Engine compartment'],
    description: 'Rare alpha test M4A4 with upgraded engine and combat characteristics.',
    armor: { front: 63, side: 38, rear: 38 },
    firepower: { damage: 120, penetration: 128, rateOfFire: 7.5 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.5 },
    special: 'Alpha test collectible',
    image: '/tanks/m4a4-alpha.png'
  },
  {
    id: 'valentine-ix',
    name: 'Valentine IX (2025 valentine platinum)',
    tier: 'Tier III',
    type: 'Light Tank',
    nation: 'UK',
    status: 'Platinum',
    ammoType: ['APBC', 'APC BC', 'HE'],
    playstyle: {
      name: 'Scout Support',
      description: 'Reconnaissance and spotting for team while providing fire support',
      howTo: [
        'Use speed to scout enemy positions',
        'Spot enemies for team to target',
        'Provide supporting fire when safe',
        'Use terrain for cover while scouting',
        'Fall back when spotted by enemies'
      ]
    },
    weakspots: ['Thin armor all around', 'Large profile', 'Slow speed', 'Limited gun depression'],
    description: 'British light tank with Valentine Platinum event camouflage.',
    armor: { front: 30, side: 20, rear: 20 },
    firepower: { damage: 70, penetration: 61, rateOfFire: 12.0 },
    mobility: { speed: 32, reverseSpeed: 16, powerToWeight: 9.8 },
    special: '2025 Valentine Platinum event',
    image: '/tanks/valentine-ix.png'
  },
  {
    id: 'rbt-5',
    name: 'RBT-5 (2025 april fools event)',
    tier: 'Tier II',
    type: 'Light Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['Rocket Projectiles', 'APBC', 'HE'],
    playstyle: {
      name: 'Rocket Rush',
      description: 'Surprise enemies with devastating rocket attacks',
      howTo: [
        'Use rockets to destroy enemy cover and fortifications',
        'Attack from the sides for maximum effectiveness',
        'Combine rockets with direct fire for damage',
        'Use speed to escape after rocket attacks',
        'Target groups of enemies for area saturation'
      ]
    },
    weakspots: ['Very thin armor (13mm)', 'External rockets', 'Large profile', 'Limited firepower'],
    description: 'Experimental Soviet tank with rocket launchers. April Fools event.',
    armor: { front: 13, side: 10, rear: 8 },
    firepower: { damage: 145, penetration: 120, rateOfFire: 4.0 },
    mobility: { speed: 52, reverseSpeed: 25, powerToWeight: 18.5 },
    special: '2025 April Fools event',
    image: '/tanks/rbt-5.png'
  },
  {
    id: 'churchill-i-alpha',
    name: 'Churchill I (alpha test collectible)',
    tier: 'Tier IV',
    type: 'Heavy Tank',
    nation: 'UK',
    status: 'Collectible',
    ammoType: ['APBC', 'HE', 'APC BC'],
    playstyle: {
      name: 'Siege Breaker',
      description: 'Lead assaults on fortified positions with overwhelming armor',
      howTo: [
        'Advance slowly but steadily toward enemy positions',
        'Use thick armor to absorb enemy fire while advancing',
        'Target enemy fortifications and defensive structures',
        'Create breakthroughs for lighter forces to exploit',
        'Never retreat - push forward relentlessly'
      ]
    },
    weakspots: ['Lower glacis (102mm at 30°)', 'Turret sides', 'Commander cupola', 'Slow speed'],
    description: 'British heavy tank with thick armor but very slow speed. Alpha collectible.',
    armor: { front: 88, side: 50, rear: 38 },
    firepower: { damage: 120, penetration: 93, rateOfFire: 6.5 },
    mobility: { speed: 20, reverseSpeed: 10, powerToWeight: 7.2 },
    special: 'Alpha test collectible',
    image: '/tanks/churchill-i-alpha.png'
  },
  {
    id: 'm4-promo',
    name: 'M4 (promo)',
    tier: 'Tier III',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Promotional',
    ammoType: ['APCBC', 'APC BC', 'HE'],
    playstyle: {
      name: 'Promo Warrior',
      description: 'Show off your promotional vehicle with aggressive gameplay',
      howTo: [
        'Play aggressively to maximize bonus rewards',
        'Lead charges to capture objectives quickly',
        'Use balanced stats to dominate early game',
        'Support team with versatile combat capabilities',
        'Make highlight plays with risky maneuvers'
      ]
    },
    weakspots: ['Turret transition', 'Lower glacis', 'Side armor', 'Mantlet'],
    description: 'Promotional M4 Sherman with special camouflage and bonus rewards.',
    armor: { front: 51, side: 38, rear: 38 },
    firepower: { damage: 110, penetration: 78, rateOfFire: 8.0 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 14.5 },
    special: 'Promotional vehicle',
    image: '/tanks/m4-promo.png'
  },
  {
    id: 'm4a2',
    name: 'M4A2',
    tier: 'Tier IV',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Standard',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'Diesel Power',
      description: 'Use superior fuel efficiency for extended battlefield operations',
      howTo: [
        'Stay in combat longer without returning to base',
        'Use extended range to support distant operations',
        'Exploit enemy fuel shortages with sustained pressure',
        'Lead deep strikes into enemy territory',
        'Maintain constant presence on the battlefield'
      ]
    },
    weakspots: ['Turret cheeks', 'Lower glacis', 'Side hull', 'Engine deck'],
    description: 'Diesel-powered M4 Sherman with better fuel efficiency and reduced fire risk.',
    armor: { front: 51, side: 38, rear: 38 },
    firepower: { damage: 110, penetration: 92, rateOfFire: 8.0 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 14.5 },
    image: '/tanks/m4a2.png'
  },
  {
    id: 't34-1942',
    name: 'T34 (1942)',
    tier: 'Tier V',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Standard',
    ammoType: ['BR-350A APBC', 'BR-350P APCR', 'F-354 HE'],
    playstyle: {
      name: 'Steel Wall',
      description: 'Form an impenetrable defense with enhanced armor',
      howTo: [
        'Position at key chokepoints to block enemy advances',
        'Use angled armor to bounce incoming shells',
        'Push forward gradually to gain ground',
        'Support lighter tanks with your presence',
        'Never expose your weak sides to enemy fire'
      ]
    },
    weakspots: ['Turret ring', 'Lower glacis', 'Side armor', 'Commander hatch'],
    description: 'Improved 1942 T-34 with enhanced armor and upgraded 76mm gun.',
    armor: { front: 60, side: 45, rear: 40 },
    firepower: { damage: 120, penetration: 86, rateOfFire: 7.0 },
    mobility: { speed: 34, reverseSpeed: 15, powerToWeight: 11.8 },
    image: '/tanks/t34-1942.png'
  },
  {
    id: 'chi-nu-ii',
    name: 'Chi-Nu II',
    tier: 'Tier IV',
    type: 'Medium Tank',
    nation: 'Japan',
    status: 'Standard',
    ammoType: ['Type 1 APHE', 'Type 1 APBC', 'Type 97 HE'],
    playstyle: {
      name: 'Precision Striker',
      description: 'Use accurate gun to eliminate enemies from safe distances',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at maximum effective range',
        'Aim carefully for weakspot hits',
        'Use terrain for protection while sniping',
        'Relocate frequently to avoid counter-fire'
      ]
    },
    weakspots: ['Thin turret (50mm)', 'Hull sides (20mm)', 'Large profile', 'Limited depression'],
    description: 'Japanese medium tank with 75mm gun. Excellent firepower but weak armor.',
    armor: { front: 50, side: 20, rear: 20 },
    firepower: { damage: 115, penetration: 100, rateOfFire: 8.0 },
    mobility: { speed: 44, reverseSpeed: 18, powerToWeight: 12.5 },
    image: '/tanks/chi-nu-ii.png'
  },
  {
    id: 'avenger',
    name: 'Avenger',
    tier: 'Tier V',
    type: 'Tank Destroyer',
    nation: 'USA',
    status: 'Standard',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'Long Hunter',
      description: 'Destroy enemies from extreme distances with powerful 90mm gun',
      howTo: [
        'Position at maximum engagement range (800m+)',
        'Use camouflage and concealment effectively',
        'Target high-value enemies first',
        'Aim for weakspots to ensure kills',
        'Fall back to secondary positions when detected'
      ]
    },
    weakspots: ['Open top', 'Large casemate', 'Side armor', 'Limited traverse'],
    description: 'American TD based on M4 chassis with powerful 90mm gun.',
    armor: { front: 76, side: 38, rear: 25 },
    firepower: { damage: 160, penetration: 160, rateOfFire: 6.0 },
    mobility: { speed: 42, reverseSpeed: 20, powerToWeight: 14.2 },
    image: '/tanks/avenger.png'
  },
  {
    id: 'dicker-max-premium',
    name: 'Dicker Max (premium)',
    tier: 'Tier V',
    type: 'Tank Destroyer',
    nation: 'Germany',
    status: 'Premium',
    ammoType: ['PzGr.39/43 APCBC', 'PzGr.40/43 APCR', 'Gr.39 HL HEAT', 'Sprgr.43 HE'],
    playstyle: {
      name: 'Extreme Sniper',
      description: 'Engage enemies from maximum range with unparalleled penetration',
      howTo: [
        'Find positions with 1000m+ line of sight',
        'Use APCR for heavily armored targets at range',
        'Target enemy weakspots with precision',
        'Remain stationary for maximum accuracy',
        'Use cover to conceal your position'
      ]
    },
    weakspots: ['Open top', 'Thin side armor', 'Large profile', 'Limited traverse'],
    description: 'German experimental TD with 105mm gun providing exceptional penetration.',
    armor: { front: 30, side: 15, rear: 15 },
    firepower: { damage: 160, penetration: 200, rateOfFire: 6.5 },
    mobility: { speed: 40, reverseSpeed: 18, powerToWeight: 13.8 },
    image: '/tanks/dicker-max-premium.png'
  },
  {
    id: 'calliope-premium',
    name: 'Calliope (premium)',
    tier: 'Tier V',
    type: 'Self-propelled Gun',
    nation: 'USA',
    status: 'Premium',
    ammoType: ['M8 Rockets', 'HE', 'WP Smoke'],
    playstyle: {
      name: 'Rocket Barrage',
      description: 'Saturation bombard enemy positions with devastating rockets',
      howTo: [
        'Target enemy concentrations and capture points',
        'Use rockets to destroy enemy cover',
        'Create smoke screens for team advances',
        'Bombard enemy positions for maximum disruption',
        'Combine rockets with direct fire for versatility'
      ]
    },
    weakspots: ['Open top', 'Large rocket launcher', 'Thin armor', 'Limited direct combat'],
    description: 'Sherman equipped with T34 Calliope rocket launcher system.',
    armor: { front: 51, side: 38, rear: 38 },
    firepower: { damage: 400, penetration: 50, rateOfFire: 2.0 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.5 },
    special: 'Rocket artillery system',
    image: '/tanks/calliope-premium.png'
  },
  {
    id: 'zrinyi-i',
    name: 'Zrinyi I (1 year anniversary event)',
    tier: 'Tier IV',
    type: 'Tank Destroyer',
    nation: 'Hungary',
    status: 'Event',
    ammoType: ['APHE', 'APC BC', 'HE'],
    playstyle: {
      name: 'Anniversary Assault',
      description: 'Celebrate with aggressive close-range assaults',
      howTo: [
        'Lead charges to capture objectives quickly',
        'Use 105mm gun to destroy enemy fortifications',
        'Support team with direct fire',
        'Create breakthroughs for team to exploit',
        'Play aggressively to maximize event rewards'
      ]
    },
    weakspots: ['Turret front', 'Side armor', 'Open top', 'Limited depression'],
    description: 'Hungarian TD with 105mm gun for 1 year anniversary event.',
    armor: { front: 75, side: 25, rear: 25 },
    firepower: { damage: 160, penetration: 100, rateOfFire: 6.0 },
    mobility: { speed: 35, reverseSpeed: 15, powerToWeight: 11.2 },
    special: '1 year anniversary event',
    image: '/tanks/zrinyi-i.png'
  },
  {
    id: 'kv1s-winter-2024',
    name: 'KV-1S (2024 winter event)',
    tier: 'Tier V',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['BR-350A APBC', 'BR-350P APCR', 'F-354 HE'],
    playstyle: {
      name: 'Winter Blitz',
      description: 'Use winter camouflage for surprise attacks',
      howTo: [
        'Use snow cover for concealment and surprise',
        'Exploit winter camouflage to get closer to enemies',
        'Launch quick strikes against isolated targets',
        'Use speed to escape after successful attacks',
        'Coordinate with team for winter tactics'
      ]
    },
    weakspots: ['Turret ring', 'Side armor', 'Lower glacis', 'Commander hatch'],
    description: 'KV-1S with winter event camouflage. Reduced armor but improved mobility.',
    armor: { front: 75, side: 60, rear: 60 },
    firepower: { damage: 160, penetration: 86, rateOfFire: 6.5 },
    mobility: { speed: 43, reverseSpeed: 18, powerToWeight: 15.8 },
    special: '2024 winter event',
    image: '/tanks/kv1s-winter-2024.png'
  },
  {
    id: 'brummbar-halloween-2024',
    name: 'Brummbar (2024 halloween event)',
    tier: 'Tier V',
    type: 'Assault Gun',
    nation: 'Germany',
    status: 'Event',
    ammoType: ['HE', 'APC BC', 'HEAT'],
    playstyle: {
      name: 'Halloween Terror',
      description: 'Spread fear with massive HE shells and spooky camouflage',
      howTo: [
        'Use massive HE shells to destroy enemy cover',
        'Target groups of enemies for area damage',
        'Exploit Halloween camouflage for surprise attacks',
        'Create chaos with devastating bombardments',
        'Coordinate with team for themed assaults'
      ]
    },
    weakspots: ['Casemate front', 'Side armor', 'Limited traverse', 'Large profile'],
    description: 'German assault gun with 15cm howitzer and Halloween camouflage.',
    armor: { front: 100, side: 50, rear: 50 },
    firepower: { damage: 240, penetration: 100, rateOfFire: 4.0 },
    mobility: { speed: 40, reverseSpeed: 18, powerToWeight: 12.5 },
    special: '2024 Halloween event',
    image: '/tanks/brummbar-halloween-2024.png'
  },
  {
    id: 'kv2-1940-premium',
    name: 'KV-2 (1940) (premium)',
    tier: 'Tier V',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Premium',
    ammoType: ['OF-530 HE', 'BR-350A APBC', 'BR-350P APCR'],
    playstyle: {
      name: 'Early War Monster',
      description: 'Dominate early battles with massive 152mm howitzer',
      howTo: [
        'Use HE shells to destroy enemy cover and modules',
        'Target enemy groups for maximum area damage',
        'Exploit early game chaos for maximum effect',
        'Use heavy armor to absorb early game fire',
        'Create breakthroughs for team to exploit'
      ]
    },
    weakspots: ['Large turret', 'Side armor (60mm)', 'Lower hull', 'Slow traverse'],
    description: 'Early war KV-2 variant with different turret design.',
    armor: { front: 75, side: 60, rear: 60 },
    firepower: { damage: 910, penetration: 90, rateOfFire: 3.5 },
    mobility: { speed: 26, reverseSpeed: 12, powerToWeight: 10.2 },
    image: '/tanks/kv2-1940-premium.png'
  },
  {
    id: 'ebr-1951',
    name: 'E.B.R (1951)',
    tier: 'Tier VI',
    type: 'Light Tank',
    nation: 'France',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Wheel Racer',
      description: 'Use extreme road speed to flank and capture objectives',
      howTo: [
        'Use roads for maximum speed advantage',
        'Flank enemies while they are distracted',
        'Capture objectives quickly before enemies can respond',
        'Use speed to escape dangerous situations',
        'Harass enemy rear positions'
      ]
    },
    weakspots: ['Very thin armor (20mm)', 'Large wheels', 'Open top', 'Poor off-road'],
    description: 'French wheeled reconnaissance vehicle with exceptional road speed.',
    armor: { front: 20, side: 15, rear: 10 },
    firepower: { damage: 180, penetration: 144, rateOfFire: 7.5 },
    mobility: { speed: 80, reverseSpeed: 40, powerToWeight: 25.5 },
    special: 'Wheeled vehicle with high speed',
    image: '/tanks/ebr-1951.png'
  },
  {
    id: 'm4a1-76-w-standard',
    name: 'M4A1 (76) W',
    tier: 'Tier V',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Standard',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'Hit & Run',
      description: 'Strike quickly from cover, deal damage, then retreat',
      howTo: [
        'Use ridges and buildings for peek-a-boo attacks',
        'Fire 2-3 shots then immediately reverse to cover',
        'Target enemy sides and rear for maximum damage',
        'Keep moving to avoid being an easy target',
        'Use speed to reposition after each engagement'
      ]
    },
    weakspots: ['Lower glacis (51mm at 47°)', 'Turret cheeks', 'Side hull (38mm)', 'Mantlet edges'],
    description: 'Standard M4A1 with upgraded 76mm gun and wet storage.',
    armor: { front: 63, side: 38, rear: 38 },
    firepower: { damage: 115, penetration: 128, rateOfFire: 7.5 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.5 },
    image: '/tanks/m4a1-76-w-standard.png'
  },
  {
    id: 'comet-i',
    name: 'Comet I',
    tier: 'Tier VI',
    type: 'Medium Tank',
    nation: 'UK',
    status: 'Standard',
    ammoType: ['APDS', 'APC BC', 'HE'],
    playstyle: {
      name: 'Cruiser Hunter',
      description: 'Use speed and firepower to hunt down enemy tanks',
      howTo: [
        'Use superior speed to outmaneuver enemies',
        'Flank enemies to attack their weak sides',
        'Pick off isolated targets with accurate fire',
        'Use mobility to escape when outnumbered',
        'Coordinate with team for coordinated attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'British cruiser tank with powerful 77mm gun and excellent mobility.',
    armor: { front: 76, side: 38, rear: 38 },
    firepower: { damage: 180, penetration: 171, rateOfFire: 7.0 },
    mobility: { speed: 51, reverseSpeed: 20, powerToWeight: 18.5 },
    image: '/tanks/comet-i.png'
  },
  {
    id: 'excelsior-premium',
    name: 'Excelsior (premium)',
    tier: 'Tier IV',
    type: 'Heavy Tank',
    nation: 'UK',
    status: 'Premium',
    ammoType: ['APBC', 'HE', 'APC BC'],
    playstyle: {
      name: 'Assault Breaker',
      description: 'Lead assaults with thick armor and reliable gun',
      howTo: [
        'Lead charges to break enemy lines',
        'Use thick armor to absorb enemy fire',
        'Support team with breakthrough capabilities',
        'Create openings for lighter forces',
        'Never retreat from advantageous positions'
      ]
    },
    weakspots: ['Lower glacis (114mm at 60°)', 'Turret sides', 'Commander cupola', 'Limited mobility'],
    description: 'British experimental heavy tank with exceptionally thick frontal armor.',
    armor: { front: 114, side: 76, rear: 50 },
    firepower: { damage: 120, penetration: 93, rateOfFire: 6.5 },
    mobility: { speed: 38, reverseSpeed: 18, powerToWeight: 13.2 },
    image: '/tanks/excelsior-premium.png'
  },
  {
    id: 'kv-ic-756-r',
    name: 'KV IC 756 (r) (2024 april fools event)',
    tier: 'Tier V',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['APHE', 'APC BC', 'HE'],
    playstyle: {
      name: 'April Fools',
      description: 'Use experimental features for unpredictable gameplay',
      howTo: [
        'Surprise enemies with unconventional tactics',
        'Use experimental systems for unique advantages',
        'Exploit confusion caused by unusual appearance',
        'Create chaos with unpredictable movements',
        'Coordinate with team for themed strategies'
      ]
    },
    weakspots: ['Large experimental turret', 'Side armor', 'Slow speed', 'Unusual weakpoints'],
    description: 'April Fools event variant with experimental features.',
    armor: { front: 75, side: 60, rear: 60 },
    firepower: { damage: 200, penetration: 100, rateOfFire: 5.0 },
    mobility: { speed: 35, reverseSpeed: 15, powerToWeight: 11.0 },
    special: '2024 April Fools event',
    image: '/tanks/kv-ic-756-r.png'
  },
  {
    id: 't34-57-event',
    name: 'T-34-57 (event)',
    tier: 'Tier IV',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['BR-271 APBC', 'BR-271P APCR', 'F-354 HE'],
    playstyle: {
      name: 'Glass Cannon',
      description: 'Use high-velocity gun for long-range sniping',
      howTo: [
        'Engage enemies from maximum range',
        'Use high penetration to target heavy tanks',
        'Aim carefully for weakspot hits',
        'Avoid close combat due to weak armor',
        'Relocate frequently to avoid detection'
      ]
    },
    weakspots: ['Turret front', 'Side armor', 'Lower glacis', 'Large profile'],
    description: 'T-34 armed with high-velocity 57mm gun. Event vehicle.',
    armor: { front: 45, side: 45, rear: 40 },
    firepower: { damage: 85, penetration: 140, rateOfFire: 12.0 },
    mobility: { speed: 51, reverseSpeed: 20, powerToWeight: 16.5 },
    special: 'Event vehicle',
    image: '/tanks/t34-57-event.png'
  },
  {
    id: 'm64-lunar-2024-2025',
    name: 'M64 (2024-2025 lunar new year event)',
    tier: 'Tier VI',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Event',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'Lunar Warrior',
      description: 'Celebrate Lunar New Year with aggressive gameplay',
      howTo: [
        'Use special event camouflage for surprise attacks',
        'Play aggressively to maximize event rewards',
        'Lead charges to capture objectives quickly',
        'Support team with balanced combat capabilities',
        'Create highlight plays with themed tactics'
      ]
    },
    weakspots: ['Turret cheeks', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'American medium tank with Lunar New Year event camouflage.',
    armor: { front: 76, side: 38, rear: 38 },
    firepower: { damage: 180, penetration: 128, rateOfFire: 7.5 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.5 },
    special: '2024-2025 Lunar New Year event',
    image: '/tanks/m64-lunar-2024-2025.png'
  },
  {
    id: 'tiger-h1',
    name: 'Tiger H1',
    tier: 'Tier V',
    type: 'Heavy Tank',
    nation: 'Germany',
    status: 'Standard',
    ammoType: ['PzGr.39/42 APCBC', 'PzGr.40/42 APCR', 'Gr.39 HL HEAT', 'Sprgr.34 HE'],
    playstyle: {
      name: 'Long Range Dominator',
      description: 'Control battlefield from distance with superior 88mm gun',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at maximum effective range',
        'Use superior penetration to target heavy tanks',
        'Maintain distance to exploit accuracy advantage',
        'Fall back when enemies get too close'
      ]
    },
    weakspots: ['Lower glacis (100mm at 25°)', 'Turret cheeks', 'Side armor', 'Commander cupola'],
    description: 'German heavy tank with legendary 88mm gun and substantial armor.',
    armor: { front: 100, side: 80, rear: 80 },
    firepower: { damage: 160, penetration: 156, rateOfFire: 6.0 },
    mobility: { speed: 40, reverseSpeed: 18, powerToWeight: 12.3 },
    image: '/tanks/tiger-h1.png'
  },
  {
    id: 't34-85-d5t',
    name: 'T-34-85 (D-5T)',
    tier: 'Tier V',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Standard',
    ammoType: ['BR-365 APBC', 'BR-365P APCR', 'OF-350 HE'],
    playstyle: {
      name: 'All-Rounder Fighter',
      description: 'Adapt to any situation with balanced performance',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Side armor', 'Lower glacis', 'Large profile'],
    description: 'T-34 upgraded with 85mm D-5T gun in new three-man turret.',
    armor: { front: 45, side: 45, rear: 40 },
    firepower: { damage: 180, penetration: 144, rateOfFire: 7.5 },
    mobility: { speed: 51, reverseSpeed: 20, powerToWeight: 16.5 },
    image: '/tanks/t34-85-d5t.png'
  },
  {
    id: 'kv-220-premium',
    name: 'KV-220 (premium)',
    tier: 'Tier V',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Premium',
    ammoType: ['BR-350A APBC', 'BR-350P APCR', 'F-354 HE'],
    playstyle: {
      name: 'Steel Fortress',
      description: 'Use exceptionally thick armor to dominate the battlefield',
      howTo: [
        'Lead assaults with impenetrable frontal armor',
        'Angle hull to maximize armor effectiveness',
        'Push forward to gain ground for team',
        'Support lighter tanks with your presence',
        'Never expose weak sides to enemy fire'
      ]
    },
    weakspots: ['Turret ring', 'Lower glacis', 'Side armor', 'Commander hatch'],
    description: 'Soviet heavy tank prototype with exceptionally thick frontal armor.',
    armor: { front: 100, side: 80, rear: 70 },
    firepower: { damage: 160, penetration: 86, rateOfFire: 6.5 },
    mobility: { speed: 35, reverseSpeed: 15, powerToWeight: 11.5 },
    image: '/tanks/kv-220-premium.png'
  },
  {
    id: 'm4a4-sa50-premium',
    name: 'M4A4 (SA50) (premium)',
    tier: 'Tier V',
    type: 'Medium Tank',
    nation: 'France',
    status: 'Premium',
    ammoType: ['APCBC', 'APDS', 'HE'],
    playstyle: {
      name: 'French Sharpshooter',
      description: 'Use accurate SA50 gun for long-range precision strikes',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at maximum effective range',
        'Aim carefully for weakspot hits',
        'Use terrain for protection while sniping',
        'Relocate frequently to avoid counter-fire'
      ]
    },
    weakspots: ['Turret cheeks', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'French Sherman variant equipped with powerful 75mm SA50 gun.',
    armor: { front: 63, side: 38, rear: 38 },
    firepower: { damage: 180, penetration: 170, rateOfFire: 7.0 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.5 },
    image: '/tanks/m4a4-sa50-premium.png'
  },
  {
    id: 'cobra-king-premium',
    name: 'Cobra King (premium)',
    tier: 'Tier V',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Premium',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'Historic Warrior',
      description: 'Lead assaults with famous tank from Battle of the Bulge',
      howTo: [
        'Lead charges to capture objectives quickly',
        'Use historical significance for psychological advantage',
        'Support team with reliable combat performance',
        'Create breakthroughs for team to exploit',
        'Never retreat from key positions'
      ]
    },
    weakspots: ['Turret cheeks', 'Lower glacis', 'Side armor', 'Historical markings'],
    description: 'Famous Sherman tank from Battle of the Bulge, first to reach Bastogne.',
    armor: { front: 63, side: 38, rear: 38 },
    firepower: { damage: 115, penetration: 128, rateOfFire: 7.5 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.5 },
    special: 'Historical significance',
    image: '/tanks/cobra-king-premium.png'
  },
  {
    id: 'r3-t20-fa-hs-event',
    name: 'R3 T20 FA-HS (event)',
    tier: 'Tier VI',
    type: 'Light Tank',
    nation: 'Italy',
    status: 'Event',
    ammoType: ['APHE', 'HEAT', 'HE'],
    playstyle: {
      name: 'Wheeled Hunter',
      description: 'Use high mobility and firepower for hit-and-run tactics',
      howTo: [
        'Use wheels for rapid repositioning',
        'Flank enemies while they are distracted',
        'Hit enemy weakspots with accurate fire',
        'Use speed to escape dangerous situations',
        'Harass enemy rear positions'
      ]
    },
    weakspots: ['Thin armor', 'Open top', 'Large profile', 'Limited off-road'],
    description: 'Italian wheeled TD with high mobility and powerful gun.',
    armor: { front: 30, side: 15, rear: 10 },
    firepower: { damage: 180, penetration: 200, rateOfFire: 8.0 },
    mobility: { speed: 70, reverseSpeed: 35, powerToWeight: 22.5 },
    special: 'Event vehicle',
    image: '/tanks/r3-t20-fa-hs-event.png'
  },
  {
    id: 'pz-bef-wg-vi-p-event',
    name: 'Pz.Bef.Wg.VI P (event)',
    tier: 'Tier VI',
    type: 'Light Tank',
    nation: 'Germany',
    status: 'Event',
    ammoType: ['APC BC', 'HEAT', 'HE'],
    playstyle: {
      name: 'Command Scout',
      description: 'Coordinate team movements while providing reconnaissance',
      howTo: [
        'Scout enemy positions for team',
        'Coordinate team attacks and defenses',
        'Provide supporting fire when safe',
        'Use speed to escape when spotted',
        'Maintain battlefield awareness'
      ]
    },
    weakspots: ['Thin armor', 'Large profile', 'Limited firepower', 'Command equipment'],
    description: 'German command tank for battlefield coordination.',
    armor: { front: 30, side: 20, rear: 15 },
    firepower: { damage: 110, penetration: 78, rateOfFire: 8.5 },
    mobility: { speed: 55, reverseSpeed: 25, powerToWeight: 18.5 },
    special: 'Event vehicle',
    image: '/tanks/pz-bef-wg-vi-p-event.png'
  },
  {
    id: 'tiger-e-event',
    name: 'Tiger E (event)',
    tier: 'Tier V',
    type: 'Heavy Tank',
    nation: 'Germany',
    status: 'Event',
    ammoType: ['PzGr.39/42 APCBC', 'PzGr.40/42 APCR', 'Gr.39 HL HEAT', 'Sprgr.34 HE'],
    playstyle: {
      name: 'Event Dominator',
      description: 'Control battlefield with event-enhanced Tiger capabilities',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at maximum effective range',
        'Use superior penetration to target heavy tanks',
        'Maintain distance to exploit accuracy advantage',
        'Fall back when enemies get too close'
      ]
    },
    weakspots: ['Lower glacis (100mm at 25°)', 'Turret cheeks', 'Side armor', 'Commander cupola'],
    description: 'Event Tiger E with special camouflage and enhanced characteristics.',
    armor: { front: 100, side: 80, rear: 80 },
    firepower: { damage: 160, penetration: 156, rateOfFire: 6.0 },
    mobility: { speed: 40, reverseSpeed: 18, powerToWeight: 12.3 },
    special: 'Event vehicle',
    image: '/tanks/tiger-e-event.png'
  },
  {
    id: 'kv-122-event',
    name: 'KV-122 (event)',
    tier: 'Tier V',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['BR-471 APBC', 'BR-471P APCR', 'OF-471 HE'],
    playstyle: {
      name: 'Heavy Hitter',
      description: 'Devastate enemies with massive 122mm gun',
      howTo: [
        'Use massive damage to destroy enemies quickly',
        'Target enemy weakspots for one-shot kills',
        'Use HE to destroy enemy cover and modules',
        'Exploit chaos created by heavy firepower',
        'Create breakthroughs for team to exploit'
      ]
    },
    weakspots: ['Large turret', 'Side armor', 'Slow reload', 'Lower hull'],
    description: 'KV variant armed with powerful 122mm gun. Event vehicle.',
    armor: { front: 75, side: 60, rear: 60 },
    firepower: { damage: 390, penetration: 175, rateOfFire: 4.0 },
    mobility: { speed: 35, reverseSpeed: 15, powerToWeight: 11.0 },
    special: 'Event vehicle',
    image: '/tanks/kv-122-event.png'
  },
  {
    id: 't34-85-s53-event',
    name: 'T-34-85 (S-53) (event)',
    tier: 'Tier V',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['BR-365 APBC', 'BR-365P APCR', 'OF-350 HE'],
    playstyle: {
      name: 'Event All-Rounder',
      description: 'Adapt to any situation with event-enhanced capabilities',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Side armor', 'Lower glacis', 'Large profile'],
    description: 'T-34-85 variant with S-53 gun system. Event vehicle.',
    armor: { front: 45, side: 45, rear: 40 },
    firepower: { damage: 180, penetration: 144, rateOfFire: 8.0 },
    mobility: { speed: 51, reverseSpeed: 20, powerToWeight: 16.5 },
    special: 'Event vehicle',
    image: '/tanks/t34-85-s53-event.png'
  },
  {
    id: 'm4a3e2-76-w-event',
    name: 'M4A3E2 (76) W (event)',
    tier: 'Tier V',
    type: 'Heavy Tank',
    nation: 'USA',
    status: 'Event',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'Jumbo Assault',
      description: 'Lead assaults with thick armor and upgraded gun',
      howTo: [
        'Lead charges to break enemy lines',
        'Use thick armor to absorb enemy fire',
        'Support team with breakthrough capabilities',
        'Create openings for lighter forces',
        'Never retreat from advantageous positions'
      ]
    },
    weakspots: ['Turret cheeks', 'Lower glacis', 'Side armor', 'Limited mobility'],
    description: 'Jumbo Sherman with upgraded 76mm gun. Event vehicle.',
    armor: { front: 101, side: 76, rear: 38 },
    firepower: { damage: 115, penetration: 128, rateOfFire: 7.5 },
    mobility: { speed: 35, reverseSpeed: 18, powerToWeight: 11.2 },
    special: 'Event vehicle',
    image: '/tanks/m4a3e2-76-w-event.png'
  },
  {
    id: 'is1-winter-2023',
    name: 'IS-1 (2023 winter event)',
    tier: 'Tier VI',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['BR-471 APBC', 'BR-471P APCR', 'OF-471 HE'],
    playstyle: {
      name: 'Winter Breakthrough',
      description: 'Use winter camouflage and heavy armor for breakthrough assaults',
      howTo: [
        'Lead assaults with heavy armor and gun',
        'Use winter camouflage for surprise attacks',
        'Target enemy fortifications and heavy tanks',
        'Create breakthroughs for team to exploit',
        'Push forward relentlessly'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Commander cupola'],
    description: 'IS-1 heavy tank with winter event camouflage.',
    armor: { front: 120, side: 90, rear: 60 },
    firepower: { damage: 280, penetration: 175, rateOfFire: 4.5 },
    mobility: { speed: 40, reverseSpeed: 18, powerToWeight: 13.5 },
    special: '2023 winter event',
    image: '/tanks/is1-winter-2023.png'
  },
  {
    id: 'st-a1',
    name: 'ST-A1',
    tier: 'Tier VI',
    type: 'Medium Tank',
    nation: 'Japan',
    status: 'Standard',
    ammoType: ['Type 4 APHE', 'Type 1 APBC', 'Type 97 HE'],
    playstyle: {
      name: 'Precision Support',
      description: 'Provide accurate fire support from safe distances',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at maximum effective range',
        'Aim carefully for weakspot hits',
        'Use terrain for protection while supporting',
        'Relocate frequently to avoid counter-fire'
      ]
    },
    weakspots: ['Thin turret', 'Hull sides', 'Large profile', 'Limited depression'],
    description: 'Japanese medium tank prototype with 90mm gun.',
    armor: { front: 50, side: 30, rear: 25 },
    firepower: { damage: 180, penetration: 155, rateOfFire: 7.0 },
    mobility: { speed: 45, reverseSpeed: 20, powerToWeight: 16.5 },
    image: '/tanks/st-a1.png'
  },
  {
    id: 'st-a3-premium',
    name: 'ST-A3 (premium)',
    tier: 'Tier VI',
    type: 'Medium Tank',
    nation: 'Japan',
    status: 'Premium',
    ammoType: ['Type 4 APHE', 'Type 1 APBC', 'Type 97 HE'],
    playstyle: {
      name: 'Premium Precision',
      description: 'Provide accurate fire support with enhanced credit earning',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at maximum effective range',
        'Aim carefully for weakspot hits',
        'Use terrain for protection while supporting',
        'Relocate frequently to avoid counter-fire'
      ]
    },
    weakspots: ['Thin turret', 'Hull sides', 'Large profile', 'Limited depression'],
    description: 'Premium ST-A series with enhanced credit earning.',
    armor: { front: 50, side: 30, rear: 25 },
    firepower: { damage: 180, penetration: 155, rateOfFire: 7.0 },
    mobility: { speed: 45, reverseSpeed: 20, powerToWeight: 16.5 },
    image: '/tanks/st-a3-premium.png'
  },
  {
    id: 'm4a3-76w',
    name: 'M4A3 (76)W',
    tier: 'Tier V',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Standard',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'Hit & Run',
      description: 'Strike quickly from cover, deal damage, then retreat',
      howTo: [
        'Use ridges and buildings for peek-a-boo attacks',
        'Fire 2-3 shots then immediately reverse to cover',
        'Target enemy sides and rear for maximum damage',
        'Keep moving to avoid being an easy target',
        'Use speed to reposition after each engagement'
      ]
    },
    weakspots: ['Lower glacis (51mm at 47°)', 'Turret cheeks', 'Side hull (38mm)', 'Mantlet edges'],
    description: 'M4A3 Sherman with Ford engine and wet storage 76mm gun.',
    armor: { front: 63, side: 38, rear: 38 },
    firepower: { damage: 115, penetration: 128, rateOfFire: 7.5 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.5 },
    image: '/tanks/m4a3-76w.png'
  },
  {
    id: 'black-prince',
    name: 'Black Prince',
    tier: 'Tier VII',
    type: 'Heavy Tank',
    nation: 'UK',
    status: 'Standard',
    ammoType: ['APDS', 'APC BC', 'HESH', 'HE'],
    playstyle: {
      name: 'Moving Fortress',
      description: 'Use exceptionally thick armor for unstoppable advances',
      howTo: [
        'Lead assaults with impenetrable frontal armor',
        'Angle hull to maximize armor effectiveness',
        'Push forward to gain ground for team',
        'Support lighter tanks with your presence',
        'Never expose weak sides to enemy fire'
      ]
    },
    weakspots: ['Lower glacis', 'Turret sides', 'Slow speed', 'Large profile'],
    description: 'British heavy tank with exceptionally thick frontal armor.',
    armor: { front: 152, side: 114, rear: 76 },
    firepower: { damage: 230, penetration: 201, rateOfFire: 6.0 },
    mobility: { speed: 20, reverseSpeed: 10, powerToWeight: 8.5 },
    image: '/tanks/black-prince.png'
  },
  {
    id: 'is2',
    name: 'IS-2',
    tier: 'Tier VII',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Standard',
    ammoType: ['BR-471 APBC', 'BR-471P APCR', 'OF-471 HE'],
    playstyle: {
      name: 'Heavy Breakthrough',
      description: 'Lead assaults with powerful 122mm gun and thick armor',
      howTo: [
        'Lead assaults with heavy armor and gun',
        'Target enemy fortifications and heavy tanks',
        'Create breakthroughs for team to exploit',
        'Push forward relentlessly',
        'Use HE to destroy enemy cover'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Commander cupola'],
    description: 'Soviet heavy tank with powerful 122mm gun and thick armor.',
    armor: { front: 120, side: 90, rear: 60 },
    firepower: { damage: 390, penetration: 175, rateOfFire: 4.5 },
    mobility: { speed: 37, reverseSpeed: 18, powerToWeight: 13.2 },
    image: '/tanks/is2.png'
  },
  {
    id: 'panther-d',
    name: 'Panther D',
    tier: 'Tier VI',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Standard',
    ammoType: ['PzGr.39/42 APCBC', 'PzGr.40/42 APCR', 'Gr.39 HL HEAT', 'Sprgr.34 HE'],
    playstyle: {
      name: 'Long Range Hunter',
      description: 'Use superior 75mm L/70 gun for long-range combat',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at maximum effective range',
        'Use superior penetration to target heavy tanks',
        'Maintain distance to exploit accuracy advantage',
        'Fall back when enemies get too close'
      ]
    },
    weakspots: ['Lower glacis (80mm at 55°)', 'Side armor', 'Turret sides', 'Mechanical issues'],
    description: 'German Panther with excellent 75mm L/70 gun but mechanical problems.',
    armor: { front: 80, side: 50, rear: 40 },
    firepower: { damage: 180, penetration: 156, rateOfFire: 6.5 },
    mobility: { speed: 46, reverseSpeed: 20, powerToWeight: 15.8 },
    image: '/tanks/panther-d.png'
  },
  {
    id: 'm56-event',
    name: 'M56 (event)',
    tier: 'Tier VI',
    type: 'Tank Destroyer',
    nation: 'USA',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Lightning TD',
      description: 'Use extreme mobility for rapid strike operations',
      howTo: [
        'Use high mobility for rapid repositioning',
        'Flank enemies while they are distracted',
        'Hit enemy weakspots with accurate fire',
        'Use speed to escape dangerous situations',
        'Harass enemy rear positions'
      ]
    },
    weakspots: ['Open top', 'No armor', 'Large profile', 'Crew exposure'],
    description: 'American light TD with 90mm gun and extreme mobility.',
    armor: { front: 15, side: 10, rear: 10 },
    firepower: { damage: 230, penetration: 203, rateOfFire: 6.0 },
    mobility: { speed: 45, reverseSpeed: 20, powerToWeight: 28.5 },
    special: 'Event vehicle',
    image: '/tanks/m56-event.png'
  },
  {
    id: 'bfw-jagpanther-g1-event',
    name: 'Bfw.Jagpanther G1 (event)',
    tier: 'Tier VI',
    type: 'Tank Destroyer',
    nation: 'Germany',
    status: 'Event',
    ammoType: ['PzGr.39/43 APCBC', 'PzGr.40/43 APCR', 'Gr.39 HL HEAT', 'Sprgr.43 HE'],
    playstyle: {
      name: 'Event Hunter',
      description: 'Use powerful 88mm gun for long-range destruction',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at maximum effective range',
        'Use superior penetration to target heavy tanks',
        'Maintain distance to exploit accuracy advantage',
        'Fall back when enemies get too close'
      ]
    },
    weakspots: ['Side armor', 'Lower front', 'Open top', 'Limited traverse'],
    description: 'Event Jagdpanther with special camouflage and 88mm gun.',
    armor: { front: 80, side: 50, rear: 40 },
    firepower: { damage: 230, penetration: 203, rateOfFire: 6.0 },
    mobility: { speed: 46, reverseSpeed: 20, powerToWeight: 15.8 },
    special: 'Event vehicle',
    image: '/tanks/bfw-jagpanther-g1-event.png'
  },
  {
    id: 'fiat-6614-event',
    name: 'FIAT 6614 (event)',
    tier: 'Tier II',
    type: 'Light Tank',
    nation: 'Italy',
    status: 'Event',
    ammoType: ['APC BC', 'HEAT', 'HE'],
    playstyle: {
      name: 'Wheeled Scout',
      description: 'Use high speed for reconnaissance and harassment',
      howTo: [
        'Use wheels for rapid repositioning',
        'Scout enemy positions for team',
        'Harass enemy rear positions',
        'Use speed to escape dangerous situations',
        'Maintain battlefield awareness'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Limited off-road', 'Vulnerable to heavy weapons'],
    description: 'Italian wheeled armored vehicle for reconnaissance.',
    armor: { front: 15, side: 10, rear: 10 },
    firepower: { damage: 50, penetration: 40, rateOfFire: 10.0 },
    mobility: { speed: 60, reverseSpeed: 30, powerToWeight: 20.5 },
    special: 'Event vehicle',
    image: '/tanks/fiat-6614-event.png'
  },
  {
    id: 'object-248-event',
    name: 'Object 248 (event)',
    tier: 'Tier VI',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['BR-412 APBC', 'BR-412P APCR', 'OF-410 HE'],
    playstyle: {
      name: 'Prototype Warrior',
      description: 'Use experimental features for unpredictable gameplay',
      howTo: [
        'Surprise enemies with unconventional tactics',
        'Use experimental systems for unique advantages',
        'Exploit confusion caused by unusual appearance',
        'Create chaos with unpredictable movements',
        'Coordinate with team for themed strategies'
      ]
    },
    weakspots: ['Turret front', 'Side armor', 'Lower glacis', 'Experimental equipment'],
    description: 'Soviet medium tank prototype with D-10T gun.',
    armor: { front: 100, side: 80, rear: 50 },
    firepower: { damage: 180, penetration: 156, rateOfFire: 7.0 },
    mobility: { speed: 50, reverseSpeed: 20, powerToWeight: 18.5 },
    special: 'Event vehicle',
    image: '/tanks/object-248-event.png'
  },
  {
    id: 'g6-event',
    name: 'G6 (event)',
    tier: 'Tier VI',
    type: 'Self-propelled Gun',
    nation: 'South Africa',
    status: 'Event',
    ammoType: ['HE', 'HEAT', 'Smoke'],
    playstyle: {
      name: 'Long Range Artillery',
      description: 'Provide indirect fire support from maximum range',
      howTo: [
        'Position at maximum range from enemy',
        'Target enemy concentrations and capture points',
        'Use HE for area damage and module destruction',
        'Create smoke screens for team advances',
        'Relocate after each barrage to avoid counter-fire'
      ]
    },
    weakspots: ['Open top', 'Large profile', 'Thin armor', 'Limited direct combat'],
    description: 'South African self-propelled howitzer with 155mm gun.',
    armor: { front: 20, side: 15, rear: 15 },
    firepower: { damage: 850, penetration: 65, rateOfFire: 2.5 },
    mobility: { speed: 40, reverseSpeed: 20, powerToWeight: 12.5 },
    special: 'Event vehicle',
    image: '/tanks/g6-event.png'
  },
  {
    id: 'ersatz-m10-event',
    name: 'Ersatz M10 (event)',
    tier: 'Tier V',
    type: 'Tank Destroyer',
    nation: 'Germany',
    status: 'Event',
    ammoType: ['PzGr.39 APCBC', 'PzGr.40 APCR', 'Gr.38 HL HEAT', 'Sprgr.34 HE'],
    playstyle: {
      name: 'Disguised Hunter',
      description: 'Use captured vehicle appearance for deception tactics',
      howTo: [
        'Exploit enemy confusion with captured appearance',
        'Ambush enemies who mistake you for friendly',
        'Use deception to get close to enemies',
        'Strike when enemies least expect it',
        'Create chaos with psychological warfare'
      ]
    },
    weakspots: ['Thin armor', 'Open top', 'Large profile', 'Disguise limitations'],
    description: 'German TD disguised as American M10 for deception.',
    armor: { front: 50, side: 30, rear: 25 },
    firepower: { damage: 160, penetration: 156, rateOfFire: 6.5 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.5 },
    special: 'Event vehicle',
    image: '/tanks/ersatz-m10-event.png'
  },
  {
    id: 'panther-f',
    name: 'Panther F',
    tier: 'Tier VI',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Standard',
    ammoType: ['PzGr.39/42 APCBC', 'PzGr.40/42 APCR', 'Gr.39 HL HEAT', 'Sprgr.34 HE'],
    playstyle: {
      name: 'Enhanced Hunter',
      description: 'Use improved Schmalturm turret for better protection',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at maximum effective range',
        'Use improved turret for better protection',
        'Maintain distance to exploit accuracy advantage',
        'Fall back when enemies get too close'
      ]
    },
    weakspots: ['Lower glacis (80mm at 55°)', 'Side armor', 'Turret ring', 'Schmalturm limitations'],
    description: 'Improved Panther with Schmalturm turret and enhanced armor.',
    armor: { front: 80, side: 50, rear: 40 },
    firepower: { damage: 180, penetration: 203, rateOfFire: 6.5 },
    mobility: { speed: 46, reverseSpeed: 20, powerToWeight: 15.8 },
    image: '/tanks/panther-f.png'
  },
  {
    id: 'char-25t',
    name: 'Char 25t',
    tier: 'Tier VII',
    type: 'Light Tank',
    nation: 'France',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Auto Loader',
      description: 'Use rapid fire auto-loader for burst damage',
      howTo: [
        'Use 5-round magazine for burst damage',
        'Flank enemies while they are reloading',
        'Exploit auto-loader for quick kills',
        'Relocate during long magazine reload',
        'Coordinate with team for synchronized attacks'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Long reload', 'Limited protection'],
    description: 'French light tank with 5-round auto-loader system.',
    armor: { front: 20, side: 15, rear: 15 },
    firepower: { damage: 135, penetration: 144, rateOfFire: 18.0 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 22.5 },
    special: 'Auto-loader with 5-round magazine',
    image: '/tanks/char-25t.png'
  },
  {
    id: 'm26e1',
    name: 'M26E1',
    tier: 'Tier VII',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Standard',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'Heavy Medium',
      description: 'Use heavy armor and firepower for breakthrough operations',
      howTo: [
        'Lead assaults with heavy armor and gun',
        'Target enemy fortifications and heavy tanks',
        'Create breakthroughs for team to exploit',
        'Push forward relentlessly',
        'Use HE to destroy enemy cover'
      ]
    },
    weakspots: ['Lower glacis', 'Turret cheeks', 'Side armor', 'Large profile'],
    description: 'Upgraded Pershing with improved 90mm gun and mobility.',
    armor: { front: 101, side: 76, rear: 50 },
    firepower: { damage: 240, penetration: 190, rateOfFire: 6.0 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.2 },
    image: '/tanks/m26e1.png'
  },
  {
    id: 't44',
    name: 'T-44',
    tier: 'Tier VII',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Standard',
    ammoType: ['BR-365 APBC', 'BR-365P APCR', 'OF-350 HE'],
    playstyle: {
      name: 'Mobile Warrior',
      description: 'Use superior mobility for aggressive flanking',
      howTo: [
        'Use high mobility for rapid repositioning',
        'Flank enemies while they are distracted',
        'Hit enemy weakspots with accurate fire',
        'Use speed to escape dangerous situations',
        'Harass enemy rear positions'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Soviet medium tank with excellent mobility and decent armor.',
    armor: { front: 120, side: 75, rear: 45 },
    firepower: { damage: 230, penetration: 180, rateOfFire: 7.0 },
    mobility: { speed: 51, reverseSpeed: 20, powerToWeight: 18.5 },
    image: '/tanks/t44.png'
  },
  {
    id: 'fv4202',
    name: 'FV4202',
    tier: 'Tier VII',
    type: 'Medium Tank',
    nation: 'UK',
    status: 'Standard',
    ammoType: ['APDS', 'APC BC', 'HESH', 'HE'],
    playstyle: {
      name: 'Hull Down Master',
      description: 'Use excellent gun depression for hull-down tactics',
      howTo: [
        'Find ridges and terrain for hull-down positions',
        'Use excellent gun depression to your advantage',
        'Engage enemies while minimizing exposure',
        'Aim for enemy weakspots with precision',
        'Fall back when position is compromised'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'British medium tank with exceptional gun depression.',
    armor: { front: 76, side: 50, rear: 38 },
    firepower: { damage: 230, penetration: 201, rateOfFire: 6.0 },
    mobility: { speed: 50, reverseSpeed: 20, powerToWeight: 17.5 },
    image: '/tanks/fv4202.png'
  },
  {
    id: 'tiger-ii-h-sla16-premium',
    name: 'Tiger II (H) Sla.16 (premium)',
    tier: 'Tier VII',
    type: 'Heavy Tank',
    nation: 'Germany',
    status: 'Premium',
    ammoType: ['PzGr.39/43 APCBC', 'PzGr.40/43 APCR', 'Gr.39 HL HEAT', 'Sprgr.43 HE'],
    playstyle: {
      name: 'King Dominator',
      description: 'Control battlefield with superior armor and 105mm gun',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at maximum effective range',
        'Use superior armor to absorb enemy fire',
        'Target high-value enemies first',
        'Never expose weak sides to enemy fire'
      ]
    },
    weakspots: ['Lower glacis (150mm at 50°)', 'Turret cheeks', 'Side armor', 'Commander cupola'],
    description: 'Premium King Tiger with 105mm gun and exceptional armor.',
    armor: { front: 150, side: 80, rear: 80 },
    firepower: { damage: 320, penetration: 200, rateOfFire: 5.0 },
    mobility: { speed: 35, reverseSpeed: 15, powerToWeight: 10.5 },
    image: '/tanks/tiger-ii-h-sla16-premium.png'
  },
  {
    id: 'is2-revenge-premium',
    name: 'IS-2 "Revenge" (premium)',
    tier: 'Tier VII',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Premium',
    ammoType: ['BR-471 APBC', 'BR-471P APCR', 'OF-471 HE'],
    playstyle: {
      name: 'Revenge Warrior',
      description: 'Dominate with special camo and heavy firepower',
      howTo: [
        'Lead assaults with heavy armor and gun',
        'Target enemy fortifications and heavy tanks',
        'Create breakthroughs for team to exploit',
        'Push forward relentlessly',
        'Use HE to destroy enemy cover'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Commander cupola'],
    description: 'Premium IS-2 with special "Revenge" camouflage.',
    armor: { front: 120, side: 90, rear: 60 },
    firepower: { damage: 390, penetration: 175, rateOfFire: 4.5 },
    mobility: { speed: 37, reverseSpeed: 18, powerToWeight: 13.2 },
    special: 'Premium with special camo',
    image: '/tanks/is2-revenge-premium.png'
  },
  {
    id: 't29-event',
    name: 'T29 (event)',
    tier: 'Tier VII',
    type: 'Heavy Tank',
    nation: 'USA',
    status: 'Event',
    ammoType: ['APCBC', 'HVAP', 'HE'],
    playstyle: {
      name: 'Hull Down King',
      description: 'Use exceptional turret armor for hull-down dominance',
      howTo: [
        'Find ridges and terrain for hull-down positions',
        'Use exceptional turret armor to your advantage',
        'Engage enemies while minimizing exposure',
        'Aim for enemy weakspots with precision',
        'Fall back when position is compromised'
      ]
    },
    weakspots: ['Large turret', 'Lower hull', 'Side armor', 'Slow speed'],
    description: 'American heavy tank with extremely thick turret armor.',
    armor: { front: 102, side: 76, rear: 50 },
    firepower: { damage: 320, penetration: 208, rateOfFire: 4.5 },
    mobility: { speed: 35, reverseSpeed: 18, powerToWeight: 11.8 },
    special: 'Event vehicle',
    image: '/tanks/t29-event.png'
  },
  {
    id: 'amx-50-foch-event',
    name: 'AMX-50 Foch (event)',
    tier: 'Tier VII',
    type: 'Tank Destroyer',
    nation: 'France',
    status: 'Event',
    ammoType: ['APDS', 'APC BC', 'HE'],
    playstyle: {
      name: 'Auto Loader TD',
      description: 'Use rapid fire auto-loader for burst damage',
      howTo: [
        'Use 6-round magazine for burst damage',
        'Flank enemies while they are reloading',
        'Exploit auto-loader for quick kills',
        'Relocate during long magazine reload',
        'Coordinate with team for synchronized attacks'
      ]
    },
    weakspots: ['Large casemate', 'Side armor', 'Long reload', 'Limited traverse'],
    description: 'French TD with 6-round auto-loader and thick frontal armor.',
    armor: { front: 180, side: 40, rear: 30 },
    firepower: { damage: 240, penetration: 212, rateOfFire: 12.0 },
    mobility: { speed: 40, reverseSpeed: 18, powerToWeight: 14.5 },
    special: 'Event vehicle with auto-loader',
    image: '/tanks/amx-50-foch-event.png'
  },
  {
    id: 'auf1-event',
    name: 'AuF1 (event)',
    tier: 'Tier VII',
    type: 'Self-propelled Gun',
    nation: 'France',
    status: 'Event',
    ammoType: ['HE', 'HEAT', 'Smoke'],
    playstyle: {
      name: 'French Artillery',
      description: 'Provide long-range fire support with 155mm howitzer',
      howTo: [
        'Position at maximum range from enemy',
        'Target enemy concentrations and capture points',
        'Use HE for area damage and module destruction',
        'Create smoke screens for team advances',
        'Relocate after each barrage to avoid counter-fire'
      ]
    },
    weakspots: ['Open top', 'Large profile', 'Thin armor', 'Limited direct combat'],
    description: 'French self-propelled gun with 155mm howitzer.',
    armor: { front: 20, side: 15, rear: 15 },
    firepower: { damage: 950, penetration: 75, rateOfFire: 2.0 },
    mobility: { speed: 40, reverseSpeed: 20, powerToWeight: 12.5 },
    special: 'Event vehicle',
    image: '/tanks/auf1-event.png'
  },
  {
    id: 'ho-ri-production-event',
    name: 'Ho-Ri Production (event)',
    tier: 'Tier VII',
    type: 'Tank Destroyer',
    nation: 'Japan',
    status: 'Event',
    ammoType: ['APC BC', 'APHE', 'HE'],
    playstyle: {
      name: 'Japanese Heavy TD',
      description: 'Use thick casemate armor and powerful gun for long-range combat',
      howTo: [
        'Find elevated positions with good visibility',
        'Engage enemies at maximum effective range',
        'Use thick frontal armor to absorb enemy fire',
        'Target high-value enemies first',
        'Never expose weak sides to enemy fire'
      ]
    },
    weakspots: ['Casemate sides', 'Open top', 'Large profile', 'Limited traverse'],
    description: 'Japanese heavy TD with 105mm gun and thick armor.',
    armor: { front: 100, side: 50, rear: 30 },
    firepower: { damage: 320, penetration: 212, rateOfFire: 5.0 },
    mobility: { speed: 35, reverseSpeed: 15, powerToWeight: 11.5 },
    special: 'Event vehicle',
    image: '/tanks/ho-ri-production-event.png'
  },
  {
    id: 'bmp-1-platinum',
    name: 'BMP-1 (platinum)',
    tier: 'Tier VII',
    type: 'Light Tank',
    nation: 'USSR',
    status: 'Platinum',
    ammoType: ['APDS', 'HEAT', 'HE', 'ATGM'],
    playstyle: {
      name: 'Missile Scout',
      description: 'Use ATGM capability for long-range destruction',
      howTo: [
        'Use ATGMs for long-range precision strikes',
        'Target enemy weakspots with missile accuracy',
        'Use speed to escape after missile attacks',
        'Coordinate with team for missile support',
        'Exploit missile range advantage'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Open top', 'Limited protection'],
    description: 'Soviet IFV with ATGM capability. Platinum vehicle.',
    armor: { front: 20, side: 15, rear: 15 },
    firepower: { damage: 180, penetration: 250, rateOfFire: 6.0 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    special: 'Platinum vehicle with ATGM',
    image: '/tanks/bmp-1-platinum.png'
  },
  {
    id: 'sholef-event',
    name: 'Sholef (event)',
    tier: 'Tier VII',
    type: 'Self-propelled Gun',
    nation: 'Israel',
    status: 'Event',
    ammoType: ['HE', 'HEAT', 'Smoke'],
    playstyle: {
      name: 'Rapid Fire Artillery',
      description: 'Provide high rate of fire artillery support',
      howTo: [
        'Position at maximum range from enemy',
        'Target enemy concentrations and capture points',
        'Use high rate of fire for sustained bombardment',
        'Create smoke screens for team advances',
        'Relocate frequently to avoid counter-fire'
      ]
    },
    weakspots: ['Open top', 'Large profile', 'Thin armor', 'Limited direct combat'],
    description: 'Israeli SPG with high rate of fire.',
    armor: { front: 25, side: 20, rear: 20 },
    firepower: { damage: 850, penetration: 75, rateOfFire: 3.5 },
    mobility: { speed: 45, reverseSpeed: 20, powerToWeight: 15.5 },
    special: 'Event vehicle',
    image: '/tanks/sholef-event.png'
  },
  {
    id: 'centurion-action-x-platinum',
    name: 'Centurion Action X (platinum)',
    tier: 'Tier VIII',
    type: 'Medium Tank',
    nation: 'UK',
    status: 'Platinum',
    ammoType: ['APDS', 'APC BC', 'HESH', 'HE'],
    playstyle: {
      name: 'Platinum Hull Down',
      description: 'Use exceptional gun depression for hull-down dominance',
      howTo: [
        'Find ridges and terrain for hull-down positions',
        'Use excellent gun depression to your advantage',
        'Engage enemies while minimizing exposure',
        'Aim for enemy weakspots with precision',
        'Fall back when position is compromised'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Platinum Centurion with improved turret and mobility.',
    armor: { front: 152, side: 76, rear: 50 },
    firepower: { damage: 280, penetration: 268, rateOfFire: 6.0 },
    mobility: { speed: 50, reverseSpeed: 20, powerToWeight: 17.5 },
    special: 'Platinum vehicle',
    image: '/tanks/centurion-action-x-platinum.png'
  },
  {
    id: 'btr-80a-event',
    name: 'BTR-80A (event)',
    tier: 'Tier VII',
    type: 'Light Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Wheeled Scout',
      description: 'Use high speed for reconnaissance and harassment',
      howTo: [
        'Use wheels for rapid repositioning',
        'Scout enemy positions for team',
        'Harass enemy rear positions',
        'Use speed to escape dangerous situations',
        'Maintain battlefield awareness'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Wheeled vulnerability', 'Limited protection'],
    description: 'Soviet wheeled APC with enhanced armament.',
    armor: { front: 15, side: 10, rear: 10 },
    firepower: { damage: 180, penetration: 144, rateOfFire: 8.0 },
    mobility: { speed: 80, reverseSpeed: 40, powerToWeight: 28.5 },
    special: 'Event vehicle',
    image: '/tanks/btr-80a-event.png'
  },
  {
    id: 'ru-251-event',
    name: 'Ru 251 (event)',
    tier: 'Tier VII',
    type: 'Light Tank',
    nation: 'Germany',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Speed Demon',
      description: 'Use extreme speed for rapid reconnaissance and harassment',
      howTo: [
        'Use extreme speed for rapid repositioning',
        'Scout enemy positions for team',
        'Harass enemy rear positions',
        'Use speed to escape dangerous situations',
        'Maintain battlefield awareness'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Light construction', 'Limited protection'],
    description: 'German light tank prototype with exceptional speed.',
    armor: { front: 25, side: 15, rear: 15 },
    firepower: { damage: 180, penetration: 203, rateOfFire: 8.5 },
    mobility: { speed: 78, reverseSpeed: 35, powerToWeight: 28.5 },
    special: 'Event vehicle',
    image: '/tanks/ru-251-event.png'
  },
  {
    id: 'centurion-mk5-1-event',
    name: 'Centurion Mk.5/1 (event)',
    tier: 'Tier VIII',
    type: 'Medium Tank',
    nation: 'UK',
    status: 'Event',
    ammoType: ['APDS', 'APC BC', 'HESH', 'HE'],
    playstyle: {
      name: 'Event Centurion',
      description: 'Use enhanced capabilities for battlefield dominance',
      howTo: [
        'Find ridges and terrain for hull-down positions',
        'Use excellent gun depression to your advantage',
        'Engage enemies while minimizing exposure',
        'Aim for enemy weakspots with precision',
        'Fall back when position is compromised'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Event Centurion with enhanced armor and firepower.',
    armor: { front: 152, side: 76, rear: 50 },
    firepower: { damage: 280, penetration: 268, rateOfFire: 6.0 },
    mobility: { speed: 50, reverseSpeed: 20, powerToWeight: 17.5 },
    special: 'Event vehicle',
    image: '/tanks/centurion-mk5-1-event.png'
  },
  {
    id: 'type-62-event',
    name: 'Type 62 (event)',
    tier: 'Tier VII',
    type: 'Light Tank',
    nation: 'China',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Chinese Scout',
      description: 'Use balanced performance for reconnaissance and combat',
      howTo: [
        'Use balanced stats for versatile scouting',
        'Scout enemy positions for team',
        'Harass enemy rear positions',
        'Use speed to escape dangerous situations',
        'Maintain battlefield awareness'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Limited protection', 'Light construction'],
    description: 'Chinese light tank based on Type 59 design.',
    armor: { front: 25, side: 15, rear: 15 },
    firepower: { damage: 180, penetration: 144, rateOfFire: 8.0 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 22.5 },
    special: 'Event vehicle',
    image: '/tanks/type-62-event.png'
  },
  {
    id: 't92-event',
    name: 'T92 (event)',
    tier: 'Tier VII',
    type: 'Light Tank',
    nation: 'USA',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Airborne Scout',
      description: 'Use light armor and speed for rapid reconnaissance',
      howTo: [
        'Use light armor for rapid deployment',
        'Scout enemy positions for team',
        'Harass enemy rear positions',
        'Use speed to escape dangerous situations',
        'Maintain battlefield awareness'
      ]
    },
    weakspots: ['Very thin armor', 'Light construction', 'Airborne limitations', 'Limited protection'],
    description: 'American airborne light tank for rapid deployment.',
    armor: { front: 25, side: 15, rear: 15 },
    firepower: { damage: 180, penetration: 144, rateOfFire: 8.0 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    special: 'Event vehicle',
    image: '/tanks/t92-event.png'
  },
  {
    id: 'leopard-i',
    name: 'Leopard I',
    tier: 'Tier VIII',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Speed Hunter',
      description: 'Use extreme mobility for aggressive flanking',
      howTo: [
        'Use extreme speed for rapid repositioning',
        'Flank enemies while they are distracted',
        'Hit enemy weakspots with accurate fire',
        'Use speed to escape dangerous situations',
        'Harass enemy rear positions'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Light construction', 'Limited protection'],
    description: 'German MBT prototype prioritizing mobility over armor.',
    armor: { front: 30, side: 25, rear: 20 },
    firepower: { damage: 280, penetration: 237, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    image: '/tanks/leopard-i.png'
  },
  {
    id: 't54-1949',
    name: 'T-54 (1949)',
    tier: 'Tier VIII',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Standard',
    ammoType: ['BR-412 APBC', 'BR-412P APCR', 'OF-410 HE'],
    playstyle: {
      name: 'Balanced Warrior',
      description: 'Use balanced performance for versatile combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Soviet MBT with excellent armor and reliable 100mm gun.',
    armor: { front: 120, side: 80, rear: 45 },
    firepower: { damage: 280, penetration: 201, rateOfFire: 7.0 },
    mobility: { speed: 56, reverseSpeed: 20, powerToWeight: 18.5 },
    image: '/tanks/t54-1949.png'
  },
  {
    id: 'm47',
    name: 'M47',
    tier: 'Tier VIII',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Patton Warrior',
      description: 'Use 90mm gun and mobility for versatile combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Large turret', 'Lower glacis', 'Side armor', 'Commander cupola'],
    description: 'American Patton series medium tank with 90mm gun.',
    armor: { front: 110, side: 76, rear: 50 },
    firepower: { damage: 280, penetration: 237, rateOfFire: 6.0 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.5 },
    image: '/tanks/m47.png'
  },
  {
    id: 't54e1-premium',
    name: 'T54E1 (premium)',
    tier: 'Tier VIII',
    type: 'Heavy Tank',
    nation: 'USA',
    status: 'Premium',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Auto Loader Heavy',
      description: 'Use 4-round auto-loader for burst damage',
      howTo: [
        'Use 4-round magazine for burst damage',
        'Flank enemies while they are reloading',
        'Exploit auto-loader for quick kills',
        'Relocate during long magazine reload',
        'Coordinate with team for synchronized attacks'
      ]
    },
    weakspots: ['Large turret', 'Side armor', 'Long reload', 'Limited mobility'],
    description: 'American heavy tank with 4-round auto-loader system.',
    armor: { front: 127, side: 76, rear: 50 },
    firepower: { damage: 280, penetration: 196, rateOfFire: 12.0 },
    mobility: { speed: 42, reverseSpeed: 18, powerToWeight: 13.5 },
    special: 'Auto-loader with 4-round magazine',
    image: '/tanks/t54e1-premium.png'
  },
  {
    id: 'is6-event',
    name: 'IS-6 (event)',
    tier: 'Tier VIII',
    type: 'Heavy Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['BR-471 APBC', 'BR-471P APCR', 'OF-471 HE'],
    playstyle: {
      name: 'Spaced Armor',
      description: 'Use spaced armor design for effective defense',
      howTo: [
        'Use spaced armor to absorb enemy fire',
        'Angle hull to maximize armor effectiveness',
        'Push forward to gain ground for team',
        'Support lighter tanks with your presence',
        'Never expose weak sides to enemy fire'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Spaced armor weakpoints'],
    description: 'Soviet heavy tank with spaced armor design.',
    armor: { front: 150, side: 100, rear: 60 },
    firepower: { damage: 390, penetration: 175, rateOfFire: 4.5 },
    mobility: { speed: 35, reverseSpeed: 15, powerToWeight: 12.5 },
    special: 'Event vehicle',
    image: '/tanks/is6-event.png'
  },
  {
    id: 'object-120-event',
    name: 'Object 120 (event)',
    tier: 'Tier VIII',
    type: 'Tank Destroyer',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE', 'ATGM'],
    playstyle: {
      name: 'Missile TD',
      description: 'Use ATGM capability for long-range destruction',
      howTo: [
        'Use ATGMs for long-range precision strikes',
        'Target enemy weakspots with missile accuracy',
        'Use speed to escape after missile attacks',
        'Coordinate with team for missile support',
        'Exploit missile range advantage'
      ]
    },
    weakspots: ['Open top', 'Thin armor', 'Large profile', 'Limited protection'],
    description: 'Soviet missile-firing TD with ATGM capability.',
    armor: { front: 30, side: 20, rear: 15 },
    firepower: { damage: 280, penetration: 350, rateOfFire: 6.0 },
    mobility: { speed: 50, reverseSpeed: 20, powerToWeight: 18.5 },
    special: 'Event vehicle with ATGM',
    image: '/tanks/object-120-event.png'
  },
  {
    id: 'pzh2000hu-event',
    name: 'PzH 2000HU (event)',
    tier: 'Tier VIII',
    type: 'Self-propelled Gun',
    nation: 'Germany',
    status: 'Event',
    ammoType: ['HE', 'HEAT', 'Smoke'],
    playstyle: {
      name: 'Precision Artillery',
      description: 'Provide accurate long-range fire support',
      howTo: [
        'Position at maximum range from enemy',
        'Target enemy concentrations and capture points',
        'Use precision for accurate strikes',
        'Create smoke screens for team advances',
        'Relocate after each barrage to avoid counter-fire'
      ]
    },
    weakspots: ['Open top', 'Large profile', 'Thin armor', 'Limited direct combat'],
    description: 'German SPG with advanced fire control system.',
    armor: { front: 25, side: 20, rear: 20 },
    firepower: { damage: 1050, penetration: 85, rateOfFire: 2.5 },
    mobility: { speed: 40, reverseSpeed: 20, powerToWeight: 15.5 },
    special: 'Event vehicle',
    image: '/tanks/pzh2000hu-event.png'
  },
  {
    id: 'centurion-mk5-avre-event',
    name: 'Centurion Mk.5 AVRE (event)',
    tier: 'Tier VIII',
    type: 'Support Vehicle',
    nation: 'UK',
    status: 'Event',
    ammoType: ['HESH', 'HE', 'Smoke'],
    playstyle: {
      name: 'Combat Engineer',
      description: 'Destroy fortifications and provide engineering support',
      howTo: [
        'Use HESH to destroy enemy fortifications',
        'Target enemy defensive structures',
        'Create breaches for team to exploit',
        'Use smoke for tactical advantages',
        'Support team with engineering capabilities'
      ]
    },
    weakspots: ['Large turret', 'Side armor', 'Slow speed', 'Engineering equipment'],
    description: 'British combat engineer vehicle for fortification destruction.',
    armor: { front: 152, side: 76, rear: 50 },
    firepower: { damage: 850, penetration: 120, rateOfFire: 2.0 },
    mobility: { speed: 35, reverseSpeed: 15, powerToWeight: 11.5 },
    special: 'Event vehicle',
    image: '/tanks/centurion-mk5-avre-event.png'
  },
  {
    id: 'object-140-event',
    name: 'Object 140 (event)',
    tier: 'Tier IX',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['BR-412 APBC', 'BR-412P APCR', 'OF-410 HE'],
    playstyle: {
      name: 'Auto Loader Speed',
      description: 'Use auto-loader and high speed for rapid assaults',
      howTo: [
        'Use auto-loader for burst damage',
        'Use high speed for rapid repositioning',
        'Flank enemies while they are reloading',
        'Relocate during magazine reload',
        'Coordinate with team for synchronized attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Auto-loader reload'],
    description: 'Soviet medium tank prototype with auto-loader.',
    armor: { front: 120, side: 80, rear: 45 },
    firepower: { damage: 320, penetration: 235, rateOfFire: 8.0 },
    mobility: { speed: 64, reverseSpeed: 25, powerToWeight: 22.5 },
    special: 'Event vehicle',
    image: '/tanks/object-140-event.png'
  },
  {
    id: 'object-122mt-mc-platinum',
    name: 'Object 122MT "MC" (platinum)',
    tier: 'Tier IX',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Platinum',
    ammoType: ['BR-412 APBC', 'BR-412P APCR', 'OF-410 HE'],
    playstyle: {
      name: 'Platinum Auto Loader',
      description: 'Use auto-loader for burst damage with premium benefits',
      howTo: [
        'Use auto-loader for burst damage',
        'Use balanced stats for versatile combat',
        'Flank enemies while they are reloading',
        'Relocate during magazine reload',
        'Coordinate with team for synchronized attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Auto-loader reload'],
    description: 'Platinum Soviet medium tank with auto-loader.',
    armor: { front: 140, side: 90, rear: 50 },
    firepower: { damage: 320, penetration: 235, rateOfFire: 10.0 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 20.5 },
    special: 'Platinum vehicle',
    image: '/tanks/object-122mt-mc-platinum.png'
  },
  {
    id: 'vidar-platinum',
    name: 'VIDAR (platinum)',
    tier: 'Tier IX',
    type: 'Light Tank',
    nation: 'Sweden',
    status: 'Platinum',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Platinum Speed',
      description: 'Use extreme speed and auto-loader for rapid combat',
      howTo: [
        'Use extreme speed for rapid repositioning',
        'Use auto-loader for burst damage',
        'Flank enemies while they are reloading',
        'Relocate during magazine reload',
        'Coordinate with team for synchronized attacks'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Auto-loader reload', 'Limited protection'],
    description: 'Swedish light tank with auto-loader and extreme speed.',
    armor: { front: 20, side: 15, rear: 15 },
    firepower: { damage: 320, penetration: 220, rateOfFire: 15.0 },
    mobility: { speed: 80, reverseSpeed: 40, powerToWeight: 28.5 },
    special: 'Platinum vehicle',
    image: '/tanks/vidar-platinum.png'
  },
  {
    id: 't54e2-event',
    name: 'T54E2 (event)',
    tier: 'Tier IX',
    type: 'Heavy Tank',
    nation: 'USA',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Event Auto Loader',
      description: 'Use auto-loader for burst damage in heavy tank',
      howTo: [
        'Use auto-loader for burst damage',
        'Use heavy armor for sustained combat',
        'Flank enemies while they are reloading',
        'Relocate during magazine reload',
        'Coordinate with team for synchronized attacks'
      ]
    },
    weakspots: ['Large turret', 'Side armor', 'Long reload', 'Limited mobility'],
    description: 'American heavy tank with auto-loader system.',
    armor: { front: 127, side: 76, rear: 50 },
    firepower: { damage: 320, penetration: 196, rateOfFire: 12.0 },
    mobility: { speed: 42, reverseSpeed: 18, powerToWeight: 13.5 },
    special: 'Event vehicle',
    image: '/tanks/t54e2-event.png'
  },
  {
    id: 'm728-cev-platinum',
    name: 'M728 CEV (platinum)',
    tier: 'Tier IX',
    type: 'Support Vehicle',
    nation: 'USA',
    status: 'Platinum',
    ammoType: ['HESH', 'HE', 'Smoke'],
    playstyle: {
      name: 'Platinum Engineer',
      description: 'Destroy fortifications with engineering equipment',
      howTo: [
        'Use HESH to destroy enemy fortifications',
        'Target enemy defensive structures',
        'Create breaches for team to exploit',
        'Use smoke for tactical advantages',
        'Support team with engineering capabilities'
      ]
    },
    weakspots: ['Large turret', 'Side armor', 'Slow speed', 'Engineering equipment'],
    description: 'American combat engineer vehicle for obstacle clearing.',
    armor: { front: 152, side: 76, rear: 50 },
    firepower: { damage: 850, penetration: 120, rateOfFire: 2.0 },
    mobility: { speed: 35, reverseSpeed: 15, powerToWeight: 11.5 },
    special: 'Platinum vehicle',
    image: '/tanks/m728-cev-platinum.png'
  },
  {
    id: 'amx-10rc-platinum',
    name: 'AMX-10RC (platinum)',
    tier: 'Tier IX',
    type: 'Light Tank',
    nation: 'France',
    status: 'Platinum',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Platinum Wheeler',
      description: 'Use wheeled mobility and powerful gun for reconnaissance',
      howTo: [
        'Use wheels for rapid repositioning',
        'Use powerful gun for long-range combat',
        'Scout enemy positions for team',
        'Harass enemy rear positions',
        'Maintain battlefield awareness'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Wheeled vulnerability', 'Limited protection'],
    description: 'French wheeled reconnaissance vehicle with 105mm gun.',
    armor: { front: 20, side: 15, rear: 15 },
    firepower: { damage: 320, penetration: 220, rateOfFire: 8.0 },
    mobility: { speed: 85, reverseSpeed: 40, powerToWeight: 30.5 },
    special: 'Platinum vehicle',
    image: '/tanks/amx-10rc-platinum.png'
  },
  {
    id: 'amx-13-hot-event',
    name: 'AMX-13 (HOT) (event)',
    tier: 'Tier IX',
    type: 'Light Tank',
    nation: 'France',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE', 'ATGM'],
    playstyle: {
      name: 'Missile Light',
      description: 'Use auto-loader and ATGM for versatile combat',
      howTo: [
        'Use auto-loader for burst damage',
        'Use ATGMs for long-range precision',
        'Flank enemies while they are reloading',
        'Relocate during magazine reload',
        'Coordinate with team for synchronized attacks'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Auto-loader reload', 'Limited protection'],
    description: 'French light tank with auto-loader and ATGM.',
    armor: { front: 20, side: 15, rear: 15 },
    firepower: { damage: 320, penetration: 400, rateOfFire: 12.0 },
    mobility: { speed: 70, reverseSpeed: 35, powerToWeight: 25.5 },
    special: 'Event vehicle with ATGM',
    image: '/tanks/amx-13-hot-event.png'
  },
  {
    id: 'bkan-1c-event',
    name: 'Bkan 1C (event)',
    tier: 'Tier IX',
    type: 'Self-propelled Gun',
    nation: 'Sweden',
    status: 'Event',
    ammoType: ['HE', 'HEAT', 'Smoke'],
    playstyle: {
      name: 'Heavy Artillery',
      description: 'Provide massive firepower with 155mm howitzer',
      howTo: [
        'Position at maximum range from enemy',
        'Target enemy concentrations and capture points',
        'Use massive HE for area damage',
        'Create smoke screens for team advances',
        'Relocate after each barrage to avoid counter-fire'
      ]
    },
    weakspots: ['Open top', 'Large profile', 'Thin armor', 'Limited direct combat'],
    description: 'Swedish SPG with massive 155mm howitzer.',
    armor: { front: 25, side: 20, rear: 20 },
    firepower: { damage: 1250, penetration: 95, rateOfFire: 2.0 },
    mobility: { speed: 40, reverseSpeed: 20, powerToWeight: 15.5 },
    special: 'Event vehicle',
    image: '/tanks/bkan-1c-event.png'
  },
  {
    id: 'type-69-ila-event',
    name: 'Type 69 Ila (event)',
    tier: 'Tier IX',
    type: 'Medium Tank',
    nation: 'China',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE', 'ATGM'],
    playstyle: {
      name: 'Missile Medium',
      description: 'Use ATGM capability for long-range destruction',
      howTo: [
        'Use ATGMs for long-range precision strikes',
        'Target enemy weakspots with missile accuracy',
        'Use speed to escape after missile attacks',
        'Coordinate with team for missile support',
        'Exploit missile range advantage'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'ATGM limitations'],
    description: 'Chinese medium tank with ATGM capability.',
    armor: { front: 100, side: 80, rear: 45 },
    firepower: { damage: 320, penetration: 300, rateOfFire: 6.0 },
    mobility: { speed: 50, reverseSpeed: 20, powerToWeight: 18.5 },
    special: 'Event vehicle with ATGM',
    image: '/tanks/type-69-ila-event.png'
  },
  {
    id: 'raketenautomat-event',
    name: 'Raketenautomat (event)',
    tier: 'Tier IX',
    type: 'Tank Destroyer',
    nation: 'Germany',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE', 'ATGM'],
    playstyle: {
      name: 'Missile Auto TD',
      description: 'Use auto-loader and missiles for rapid destruction',
      howTo: [
        'Use auto-loader for burst damage',
        'Use missiles for long-range precision',
        'Flank enemies while they are reloading',
        'Relocate during magazine reload',
        'Coordinate with team for synchronized attacks'
      ]
    },
    weakspots: ['Open top', 'Thin armor', 'Large profile', 'Limited protection'],
    description: 'German missile TD with auto-loader system.',
    armor: { front: 30, side: 20, rear: 15 },
    firepower: { damage: 320, penetration: 400, rateOfFire: 12.0 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 22.5 },
    special: 'Event vehicle',
    image: '/tanks/raketenautomat-event.png'
  },
  {
    id: 'chieftain-mk3-platinum',
    name: 'Chieftain Mk3 (platinum)',
    tier: 'Tier X',
    type: 'Heavy Tank',
    nation: 'UK',
    status: 'Platinum',
    ammoType: ['APDS', 'APC BC', 'HESH', 'HE'],
    playstyle: {
      name: 'Platinum Chieftain',
      description: 'Use exceptional armor and gun for battlefield dominance',
      howTo: [
        'Find ridges and terrain for hull-down positions',
        'Use excellent gun depression to your advantage',
        'Engage enemies while minimizing exposure',
        'Aim for enemy weakspots with precision',
        'Fall back when position is compromised'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Commander cupola'],
    description: 'Platinum British MBT with exceptional armor and gun.',
    armor: { front: 200, side: 100, rear: 50 },
    firepower: { damage: 480, penetration: 326, rateOfFire: 6.0 },
    mobility: { speed: 45, reverseSpeed: 20, powerToWeight: 15.5 },
    special: 'Platinum vehicle',
    image: '/tanks/chieftain-mk3-platinum.png'
  },
  {
    id: 'm60a1-aos',
    name: 'M60A1 (AOS)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Patton Master',
      description: 'Use 105mm gun and mobility for versatile combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Large turret', 'Lower glacis', 'Side armor', 'Commander cupola'],
    description: 'American MBT with advanced fire control and 105mm gun.',
    armor: { front: 150, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.0 },
    mobility: { speed: 48, reverseSpeed: 20, powerToWeight: 15.5 },
    image: '/tanks/m60a1-aos.png'
  },
  {
    id: 't55a',
    name: 'T-55A',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Soviet Workhorse',
      description: 'Use balanced performance for reliable combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Soviet MBT with NBC protection and reliable performance.',
    armor: { front: 120, side: 80, rear: 45 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 7.0 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 20.5 },
    image: '/tanks/t55a.png'
  },
  {
    id: 'leopard-a1a1',
    name: 'Leopard A1A1',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'German Speed',
      description: 'Use exceptional mobility for aggressive combat',
      howTo: [
        'Use extreme speed for rapid repositioning',
        'Flank enemies while they are distracted',
        'Hit enemy weakspots with accurate fire',
        'Use speed to escape dangerous situations',
        'Harass enemy rear positions'
      ]
    },
    weakspots: ['Thin armor', 'Large profile', 'Light construction', 'Limited protection'],
    description: 'German MBT with improved armor and exceptional mobility.',
    armor: { front: 70, side: 40, rear: 30 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    image: '/tanks/leopard-a1a1.png'
  },
  {
    id: 'ztz88a',
    name: 'ZTZ88A',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'China',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Chinese Power',
      description: 'Use balanced performance for modern combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Chinese MBT with modern fire control and armor.',
    armor: { front: 120, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.5 },
    mobility: { speed: 56, reverseSpeed: 20, powerToWeight: 18.5 },
    image: '/tanks/ztz88a.png'
  },
  {
    id: 'strv-103c',
    name: 'Strv 103C',
    tier: 'Tier X',
    type: 'Tank Destroyer',
    nation: 'Sweden',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'S-Tank Defense',
      description: 'Use unique design for defensive operations',
      howTo: [
        'Use hydraulic suspension for hull-down tactics',
        'Find defensive positions with good cover',
        'Engage enemies while minimizing exposure',
        'Use low profile for concealment',
        'Fall back when position is compromised'
      ]
    },
    weakspots: ['No turret', 'Thin side armor', 'Fixed gun', 'Large profile'],
    description: 'Swedish S-tank with unique turretless design.',
    armor: { front: 100, side: 40, rear: 30 },
    firepower: { damage: 480, penetration: 317, rateOfFire: 6.0 },
    mobility: { speed: 50, reverseSpeed: 30, powerToWeight: 22.5 },
    special: 'No turret, hydraulic suspension',
    image: '/tanks/strv-103c.png'
  },
  {
    id: 'stb-1',
    name: 'STB-1',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Japan',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Japanese Auto Loader',
      description: 'Use auto-loader and excellent gun depression',
      howTo: [
        'Use auto-loader for burst damage',
        'Find ridges and terrain for hull-down positions',
        'Use excellent gun depression to your advantage',
        'Relocate during magazine reload',
        'Coordinate with team for synchronized attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Auto-loader reload'],
    description: 'Japanese MBT with auto-loader and excellent gun depression.',
    armor: { front: 120, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 8.0 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 20.5 },
    special: 'Auto-loader with 3-round magazine',
    image: '/tanks/stb-1.png'
  },
  {
    id: 'magach-6r',
    name: 'Magach 6R',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Israel',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Israeli Warrior',
      description: 'Use battle-proven design for effective combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Israeli modified M60 tank with improved armor.',
    armor: { front: 180, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.0 },
    mobility: { speed: 50, reverseSpeed: 20, powerToWeight: 16.5 },
    image: '/tanks/magach-6r.png'
  },
  {
    id: 'of-40-mk2a',
    name: 'OF-40 Mk.2A',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Italy',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Italian Export',
      description: 'Use reliable design for export market combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Italian MBT designed for export markets.',
    armor: { front: 120, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.0 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 20.5 },
    image: '/tanks/of-40-mk2a.png'
  },
  {
    id: 'amx-30b2-b',
    name: 'AMX-30B2 (B)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'France',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Glass Cannon',
      description: 'Use speed and firepower while avoiding damage',
      howTo: [
        'Use extreme speed for rapid repositioning',
        'Flank enemies while they are distracted',
        'Hit enemy weakspots with accurate fire',
        'Use speed to escape dangerous situations',
        'Never engage in prolonged combat'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Light construction', 'Limited protection'],
    description: 'French MBT prioritizing mobility and firepower over armor.',
    armor: { front: 50, side: 30, rear: 25 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    image: '/tanks/amx-30b2-b.png'
  },
  {
    id: 'xm1-chrysler-event',
    name: 'XM1 (Chrysler) (event)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Prototype Speed',
      description: 'Use experimental features for unpredictable gameplay',
      howTo: [
        'Surprise enemies with unconventional tactics',
        'Use experimental systems for unique advantages',
        'Exploit confusion caused by unusual appearance',
        'Create chaos with unpredictable movements',
        'Coordinate with team for themed strategies'
      ]
    },
    weakspots: ['Thin armor', 'Large profile', 'Experimental equipment', 'Limited protection'],
    description: 'American XM1 prototype with Chrysler powerplant.',
    armor: { front: 80, side: 50, rear: 30 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.5 },
    mobility: { speed: 70, reverseSpeed: 35, powerToWeight: 28.5 },
    special: 'Event vehicle',
    image: '/tanks/xm1-chrysler-event.png'
  },
  {
    id: 'maus-event',
    name: 'Maus (event)',
    tier: 'Tier X',
    type: 'Heavy Tank',
    nation: 'Germany',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Super Heavy',
      description: 'Use massive armor for unstoppable advances',
      howTo: [
        'Lead assaults with impenetrable frontal armor',
        'Angle hull to maximize armor effectiveness',
        'Push forward to gain ground for team',
        'Support lighter tanks with your presence',
        'Never expose weak sides to enemy fire'
      ]
    },
    weakspots: ['Lower glacis', 'Turret cheeks', 'Side armor', 'Slow speed'],
    description: 'German super heavy tank with exceptional armor.',
    armor: { front: 240, side: 200, rear: 160 },
    firepower: { damage: 750, penetration: 246, rateOfFire: 3.5 },
    mobility: { speed: 20, reverseSpeed: 12, powerToWeight: 6.5 },
    special: 'Event vehicle',
    image: '/tanks/maus-event.png'
  },
  {
    id: 't55amd-1-event',
    name: 'T-55AMD-1 (event)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'APS Defense',
      description: 'Use active protection system for enhanced defense',
      howTo: [
        'Use APS to intercept incoming projectiles',
        'Angle hull to maximize armor effectiveness',
        'Push forward to gain ground for team',
        'Support lighter tanks with your presence',
        'Never expose weak sides to enemy fire'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'APS limitations'],
    description: 'T-55 with active protection system.',
    armor: { front: 120, side: 80, rear: 45 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 7.0 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 20.5 },
    special: 'Event vehicle with APS',
    image: '/tanks/t55amd-1-event.png'
  },
  {
    id: 'type-74-g-event',
    name: 'Type 74 (G) (event)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Japan',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Hydro Suspension',
      description: 'Use hydraulic suspension for hull-down tactics',
      howTo: [
        'Use hydraulic suspension for hull-down positions',
        'Find ridges and terrain for advantage',
        'Engage enemies while minimizing exposure',
        'Aim for enemy weakspots with precision',
        'Fall back when position is compromised'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Hydraulic system'],
    description: 'Japanese Type 74 with hydraulic suspension.',
    armor: { front: 120, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.5 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 20.5 },
    special: 'Event vehicle',
    image: '/tanks/type-74-g-event.png'
  },
  {
    id: 'xm1-gm-platinum',
    name: 'XM1 (GM) (platinum)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Platinum',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Platinum Prototype',
      description: 'Use cutting-edge features for battlefield dominance',
      howTo: [
        'Surprise enemies with advanced capabilities',
        'Use experimental systems for unique advantages',
        'Exploit technological superiority',
        'Create chaos with advanced tactics',
        'Coordinate with team for strategic advantage'
      ]
    },
    weakspots: ['Thin armor', 'Large profile', 'Experimental equipment', 'Limited protection'],
    description: 'General Motors XM1 prototype with advanced features.',
    armor: { front: 80, side: 50, rear: 30 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.5 },
    mobility: { speed: 70, reverseSpeed: 35, powerToWeight: 28.5 },
    special: 'Platinum vehicle',
    image: '/tanks/xm1-gm-platinum.png'
  },
  {
    id: 'm60-ambt-platinum',
    name: 'M60 AMBT (platinum)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Platinum',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Platinum Auto Loader',
      description: 'Use auto-loader and enhanced armor for combat',
      howTo: [
        'Use auto-loader for burst damage',
        'Use enhanced armor for sustained combat',
        'Flank enemies while they are reloading',
        'Relocate during magazine reload',
        'Coordinate with team for synchronized attacks'
      ]
    },
    weakspots: ['Large turret', 'Side armor', 'Auto-loader reload', 'Limited mobility'],
    description: 'M60 with auto-loader and enhanced armor.',
    armor: { front: 180, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 8.0 },
    mobility: { speed: 50, reverseSpeed: 20, powerToWeight: 16.5 },
    special: 'Platinum vehicle',
    image: '/tanks/m60-ambt-platinum.png'
  },
  {
    id: 'khalid-platinum',
    name: 'Khalid (platinum)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'UK',
    status: 'Platinum',
    ammoType: ['APDS', 'APC BC', 'HESH', 'HE'],
    playstyle: {
      name: 'Platinum Export',
      description: 'Use export design for international combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'British export Chieftain for Jordan.',
    armor: { front: 180, side: 100, rear: 50 },
    firepower: { damage: 480, penetration: 326, rateOfFire: 6.0 },
    mobility: { speed: 45, reverseSpeed: 20, powerToWeight: 15.5 },
    special: 'Platinum vehicle',
    image: '/tanks/khalid-platinum.png'
  },
  {
    id: 'amx-32-event',
    name: 'AMX-32 (event)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'France',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'French Export',
      description: 'Use export design for international combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Thin armor', 'Large profile', 'Export limitations', 'Limited protection'],
    description: 'French export MBT based on AMX-30 design.',
    armor: { front: 80, side: 50, rear: 30 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    special: 'Event vehicle',
    image: '/tanks/amx-32-event.png'
  },
  {
    id: 'merkava-mk1-event',
    name: 'Merkava Mk.1 (event)',
    tier: 'Tier X',
    type: 'Heavy Tank',
    nation: 'Israel',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Troop Carrier',
      description: 'Use troop transport capability for tactical advantage',
      howTo: [
        'Use troop transport for tactical flexibility',
        'Lead assaults with heavy armor and gun',
        'Target enemy fortifications and heavy tanks',
        'Create breakthroughs for team to exploit',
        'Push forward relentlessly'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Rear troop ramp'],
    description: 'Israeli first generation Merkava with troop transport.',
    armor: { front: 200, side: 100, rear: 60 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.0 },
    mobility: { speed: 45, reverseSpeed: 20, powerToWeight: 15.5 },
    special: 'Event vehicle',
    image: '/tanks/merkava-mk1-event.png'
  },
  {
    id: 'merkava-mk2b-platinum',
    name: 'Merkava Mk.2B (platinum)',
    tier: 'Tier X',
    type: 'Heavy Tank',
    nation: 'Israel',
    status: 'Platinum',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Platinum Troop Carrier',
      description: 'Use enhanced troop transport for tactical advantage',
      howTo: [
        'Use troop transport for tactical flexibility',
        'Lead assaults with heavy armor and gun',
        'Target enemy fortifications and heavy tanks',
        'Create breakthroughs for team to exploit',
        'Push forward relentlessly'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Rear troop ramp'],
    description: 'Improved Merkava with enhanced armor and systems.',
    armor: { front: 220, side: 120, rear: 70 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.0 },
    mobility: { speed: 47, reverseSpeed: 20, powerToWeight: 16.5 },
    special: 'Platinum vehicle',
    image: '/tanks/merkava-mk2b-platinum.png'
  },
  {
    id: 'leopard-a1a1-l44-platinum',
    name: 'Leopard A1A1 (L/44) (platinum)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Platinum',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Platinum Speed',
      description: 'Use smoothbore gun and exceptional mobility',
      howTo: [
        'Use extreme speed for rapid repositioning',
        'Flank enemies while they are distracted',
        'Hit enemy weakspots with accurate fire',
        'Use speed to escape dangerous situations',
        'Harass enemy rear positions'
      ]
    },
    weakspots: ['Thin armor', 'Large profile', 'Light construction', 'Limited protection'],
    description: 'Leopard with Rheinmetall L/44 smoothbore gun.',
    armor: { front: 70, side: 40, rear: 30 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    special: 'Platinum vehicle',
    image: '/tanks/leopard-a1a1-l44-platinum.png'
  },
  {
    id: 'type-69-iig-platinum',
    name: 'Type 69 IIG (platinum)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'China',
    status: 'Platinum',
    ammoType: ['APDS', 'HEAT', 'HE', 'ATGM'],
    playstyle: {
      name: 'Platinum Missile',
      description: 'Use ATGM capability for long-range destruction',
      howTo: [
        'Use ATGMs for long-range precision strikes',
        'Target enemy weakspots with missile accuracy',
        'Use speed to escape after missile attacks',
        'Coordinate with team for missile support',
        'Exploit missile range advantage'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'ATGM limitations'],
    description: 'Chinese Type 69 with advanced ATGM capability.',
    armor: { front: 120, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 400, rateOfFire: 6.0 },
    mobility: { speed: 56, reverseSpeed: 20, powerToWeight: 18.5 },
    special: 'Platinum vehicle with ATGM',
    image: '/tanks/type-69-iig-platinum.png'
  },
  {
    id: 'type-16-fps-event',
    name: 'Type 16 (FPS) (event)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Japan',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Wheeled Warrior',
      description: 'Use wheeled mobility for rapid combat',
      howTo: [
        'Use wheels for rapid repositioning',
        'Flank enemies while they are distracted',
        'Hit enemy weakspots with accurate fire',
        'Use speed to escape dangerous situations',
        'Harass enemy rear positions'
      ]
    },
    weakspots: ['Thin armor', 'Large profile', 'Wheeled vulnerability', 'Limited protection'],
    description: 'Japanese wheeled TD with exceptional mobility.',
    armor: { front: 80, side: 50, rear: 30 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.5 },
    mobility: { speed: 80, reverseSpeed: 40, powerToWeight: 30.5 },
    special: 'Event vehicle',
    image: '/tanks/type-16-fps-event.png'
  },
  {
    id: 'object-775-platinum',
    name: 'Object 775 (platinum)',
    tier: 'Tier X',
    type: 'Light Tank',
    nation: 'USSR',
    status: 'Platinum',
    ammoType: ['APDS', 'HEAT', 'HE', 'ATGM'],
    playstyle: {
      name: 'Platinum Missile Light',
      description: 'Use missiles and high speed for rapid combat',
      howTo: [
        'Use ATGMs for long-range precision strikes',
        'Use high speed for rapid repositioning',
        'Flank enemies while they are reloading',
        'Coordinate with team for missile support',
        'Exploit speed and missile advantages'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Open top', 'Limited protection'],
    description: 'Soviet missile light tank with advanced design.',
    armor: { front: 30, side: 20, rear: 15 },
    firepower: { damage: 480, penetration: 450, rateOfFire: 8.0 },
    mobility: { speed: 70, reverseSpeed: 35, powerToWeight: 28.5 },
    special: 'Platinum vehicle with ATGM',
    image: '/tanks/object-775-platinum.png'
  },
  {
    id: 'vcc-80-60',
    name: 'VCC-80/60',
    tier: 'Tier X',
    type: 'Light Tank',
    nation: 'Italy',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'IFV Scout',
      description: 'Use IFV capabilities for versatile combat',
      howTo: [
        'Use balanced stats for versatile scouting',
        'Scout enemy positions for team',
        'Harass enemy rear positions',
        'Use speed to escape dangerous situations',
        'Maintain battlefield awareness'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'IFV limitations', 'Limited protection'],
    description: 'Italian IFV with good mobility and armament.',
    armor: { front: 25, side: 20, rear: 15 },
    firepower: { damage: 480, penetration: 220, rateOfFire: 8.0 },
    mobility: { speed: 70, reverseSpeed: 35, powerToWeight: 28.5 },
    image: '/tanks/vcc-80-60.png'
  },
  {
    id: 'chieftain-mk10',
    name: 'Chieftain Mk 10',
    tier: 'Tier X',
    type: 'Heavy Tank',
    nation: 'UK',
    status: 'Standard',
    ammoType: ['APDS', 'APC BC', 'HESH', 'HE'],
    playstyle: {
      name: 'Chieftain Master',
      description: 'Use exceptional armor and gun for battlefield dominance',
      howTo: [
        'Find ridges and terrain for hull-down positions',
        'Use excellent gun depression to your advantage',
        'Engage enemies while minimizing exposure',
        'Aim for enemy weakspots with precision',
        'Fall back when position is compromised'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Commander cupola'],
    description: 'Improved Chieftain with enhanced armor and fire control.',
    armor: { front: 220, side: 120, rear: 60 },
    firepower: { damage: 480, penetration: 326, rateOfFire: 6.0 },
    mobility: { speed: 45, reverseSpeed: 20, powerToWeight: 15.5 },
    image: '/tanks/chieftain-mk10.png'
  },
  {
    id: 'cv-90105-xc-8',
    name: 'CV 90105 XC-8',
    tier: 'Tier X',
    type: 'Light Tank',
    nation: 'Sweden',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Wheeled Destroyer',
      description: 'Use wheeled mobility and powerful gun for combat',
      howTo: [
        'Use wheels for rapid repositioning',
        'Use powerful gun for long-range combat',
        'Scout enemy positions for team',
        'Harass enemy rear positions',
        'Maintain battlefield awareness'
      ]
    },
    weakspots: ['Very thin armor', 'Large profile', 'Wheeled vulnerability', 'Limited protection'],
    description: 'Swedish wheeled TD with powerful 105mm gun.',
    armor: { front: 25, side: 20, rear: 15 },
    firepower: { damage: 480, penetration: 320, rateOfFire: 8.0 },
    mobility: { speed: 80, reverseSpeed: 40, powerToWeight: 30.5 },
    image: '/tanks/cv-90105-xc-8.png'
  },
  {
    id: 'mbt-70',
    name: 'MBT-70',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Germany/USA',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Joint Project',
      description: 'Use advanced features for battlefield dominance',
      howTo: [
        'Surprise enemies with advanced capabilities',
        'Use experimental systems for unique advantages',
        'Exploit technological superiority',
        'Create chaos with advanced tactics',
        'Coordinate with team for strategic advantage'
      ]
    },
    weakspots: ['Thin armor', 'Large profile', 'Experimental equipment', 'Limited protection'],
    description: 'German-American joint MBT project with advanced features.',
    armor: { front: 100, side: 70, rear: 40 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    image: '/tanks/mbt-70.png'
  },
  {
    id: 't72a',
    name: 'T-72A',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Soviet Power',
      description: 'Use composite armor and auto-loader for effective combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Soviet MBT with composite armor and auto-loader.',
    armor: { front: 150, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 7.0 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 20.5 },
    image: '/tanks/t72a.png'
  },
  {
    id: 'ztz96',
    name: 'ZTZ96',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'China',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Chinese Modern',
      description: 'Use modern fire control and composite armor',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Chinese MBT with modern systems and composite armor.',
    armor: { front: 150, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.5 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 20.5 },
    image: '/tanks/ztz96.png'
  },
  {
    id: 'leopard-2k',
    name: 'Leopard 2K',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Leopard Prototype',
      description: 'Use advanced features for battlefield dominance',
      howTo: [
        'Surprise enemies with advanced capabilities',
        'Use experimental systems for unique advantages',
        'Exploit technological superiority',
        'Create chaos with advanced tactics',
        'Coordinate with team for strategic advantage'
      ]
    },
    weakspots: ['Thin armor', 'Large profile', 'Experimental equipment', 'Limited protection'],
    description: 'German Leopard 2 prototype with advanced features.',
    armor: { front: 100, side: 70, rear: 40 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    image: '/tanks/leopard-2k.png'
  },
  {
    id: 'amx-40-event',
    name: 'AMX-40 (event)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'France',
    status: 'Event',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'French Prototype',
      description: 'Use export design for international combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Thin armor', 'Large profile', 'Export limitations', 'Limited protection'],
    description: 'French AMX-40 prototype for export markets.',
    armor: { front: 80, side: 50, rear: 30 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    special: 'Event vehicle',
    image: '/tanks/amx-40-event.png'
  },
  {
    id: 'leopard-2av-platinum',
    name: 'Leopard 2AV (platinum)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Platinum',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Platinum Leopard',
      description: 'Use advanced features for battlefield dominance',
      howTo: [
        'Surprise enemies with advanced capabilities',
        'Use experimental systems for unique advantages',
        'Exploit technological superiority',
        'Create chaos with advanced tactics',
        'Coordinate with team for strategic advantage'
      ]
    },
    weakspots: ['Thin armor', 'Large profile', 'Experimental equipment', 'Limited protection'],
    description: 'Leopard 2 prototype for US trials.',
    armor: { front: 100, side: 70, rear: 40 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    special: 'Platinum vehicle',
    image: '/tanks/leopard-2av-platinum.png'
  },
  {
    id: 'fv4030-3-shir-2-event',
    name: 'FV4030/3 Shir 2 (event)',
    tier: 'Tier X',
    type: 'Heavy Tank',
    nation: 'UK',
    status: 'Event',
    ammoType: ['APDS', 'APC BC', 'HESH', 'HE'],
    playstyle: {
      name: 'Shir Iran',
      description: 'Use export design for international combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'British Shir Iran 2 for export market.',
    armor: { front: 200, side: 120, rear: 60 },
    firepower: { damage: 480, penetration: 326, rateOfFire: 6.0 },
    mobility: { speed: 45, reverseSpeed: 20, powerToWeight: 15.5 },
    special: 'Event vehicle',
    image: '/tanks/fv4030-3-shir-2-event.png'
  },
  {
    id: 't72b-1989',
    name: 'T-72B (1989)',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Late Cold War',
      description: 'Use enhanced armor and systems for modern combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Improved T-72 with enhanced composite armor.',
    armor: { front: 180, side: 100, rear: 60 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 7.0 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 20.5 },
    image: '/tanks/t72b-1989.png'
  },
  {
    id: 'challenger-mk2',
    name: 'Challenger Mk.2',
    tier: 'Tier X',
    type: 'Heavy Tank',
    nation: 'UK',
    status: 'Standard',
    ammoType: ['APDS', 'APC BC', 'HESH', 'HE'],
    playstyle: {
      name: 'Challenger Master',
      description: 'Use Chobham armor and powerful gun for combat',
      howTo: [
        'Find ridges and terrain for hull-down positions',
        'Use excellent gun depression to your advantage',
        'Engage enemies while minimizing exposure',
        'Aim for enemy weakspots with precision',
        'Fall back when position is compromised'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Commander cupola'],
    description: 'British MBT with Chobham armor and 120mm gun.',
    armor: { front: 200, side: 120, rear: 60 },
    firepower: { damage: 480, penetration: 326, rateOfFire: 6.0 },
    mobility: { speed: 45, reverseSpeed: 20, powerToWeight: 15.5 },
    image: '/tanks/challenger-mk2.png'
  },
  {
    id: 'ztz96a',
    name: 'ZTZ96A',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'China',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Chinese Advanced',
      description: 'Use enhanced armor and systems for modern combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Improved Chinese MBT with enhanced systems.',
    armor: { front: 180, side: 100, rear: 60 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.5 },
    mobility: { speed: 60, reverseSpeed: 25, powerToWeight: 20.5 },
    image: '/tanks/ztz96a.png'
  },
  {
    id: 'leopard-2a4',
    name: 'Leopard 2A4',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Leopard Master',
      description: 'Use advanced armor and exceptional mobility',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'German MBT with advanced composite armor and mobility.',
    armor: { front: 150, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    image: '/tanks/leopard-2a4.png'
  },
  {
    id: 'm1-abrams',
    name: 'M1 Abrams',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Abrams Power',
      description: 'Use advanced armor and gas turbine engine',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'American MBT with advanced armor and gas turbine engine.',
    armor: { front: 180, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.0 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    image: '/tanks/m1-abrams.png'
  },
  {
    id: 'strv-121',
    name: 'Strv 121',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'Sweden',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Swedish Leopard',
      description: 'Use local modifications for Swedish combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Swedish Leopard 2 variant with local modifications.',
    armor: { front: 150, side: 80, rear: 50 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    image: '/tanks/strv-121.png'
  },
  {
    id: 't80u',
    name: 'T-80U',
    tier: 'Tier X',
    type: 'Medium Tank',
    nation: 'USSR',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Turbine Power',
      description: 'Use gas turbine engine for exceptional mobility',
      howTo: [
        'Use extreme speed for rapid repositioning',
        'Flank enemies while they are distracted',
        'Hit enemy weakspots with accurate fire',
        'Use speed to escape dangerous situations',
        'Harass enemy rear positions'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Soviet MBT with gas turbine engine and advanced armor.',
    armor: { front: 180, side: 100, rear: 60 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 7.0 },
    mobility: { speed: 70, reverseSpeed: 35, powerToWeight: 25.5 },
    image: '/tanks/t80u.png'
  },
  {
    id: 'challenger-2-tes',
    name: 'Challenger 2 TES',
    tier: 'Tier XI',
    type: 'Heavy Tank',
    nation: 'UK',
    status: 'Standard',
    ammoType: ['APDS', 'APC BC', 'HESH', 'HE'],
    playstyle: {
      name: 'TES Enhanced',
      description: 'Use TES armor package for modern combat',
      howTo: [
        'Find ridges and terrain for hull-down positions',
        'Use excellent gun depression to your advantage',
        'Engage enemies while minimizing exposure',
        'Aim for enemy weakspots with precision',
        'Fall back when position is compromised'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Commander cupola'],
    description: 'British Challenger 2 with TES armor package.',
    armor: { front: 250, side: 150, rear: 80 },
    firepower: { damage: 480, penetration: 326, rateOfFire: 6.0 },
    mobility: { speed: 45, reverseSpeed: 20, powerToWeight: 15.5 },
    image: '/tanks/challenger-2-tes.png'
  },
  {
    id: 'm1a1-hc',
    name: 'M1A1 HC',
    tier: 'Tier XI',
    type: 'Medium Tank',
    nation: 'USA',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Heavy Abrams',
      description: 'Use heavy armor configuration for modern combat',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'American M1A1 with heavy armor configuration.',
    armor: { front: 220, side: 100, rear: 60 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.0 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    image: '/tanks/m1a1-hc.png'
  },
  {
    id: 'tkx-p',
    name: 'TKX (P)',
    tier: 'Tier XI',
    type: 'Medium Tank',
    nation: 'Japan',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Type 10 Prototype',
      description: 'Use advanced systems for modern combat',
      howTo: [
        'Find ridges and terrain for hull-down positions',
        'Use excellent gun depression to your advantage',
        'Engage enemies while minimizing exposure',
        'Aim for enemy weakspots with precision',
        'Fall back when position is compromised'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Japanese Type 10 prototype with advanced systems.',
    armor: { front: 180, side: 100, rear: 60 },
    firepower: { damage: 480, penetration: 264, rateOfFire: 6.5 },
    mobility: { speed: 70, reverseSpeed: 35, powerToWeight: 28.5 },
    image: '/tanks/tkx-p.png'
  },
  {
    id: 'leopard-2a4m',
    name: 'Leopard 2A4M',
    tier: 'Tier XI',
    type: 'Medium Tank',
    nation: 'Germany',
    status: 'Standard',
    ammoType: ['APDS', 'HEAT', 'HE'],
    playstyle: {
      name: 'Canadian Enhanced',
      description: 'Use enhanced armor and mine protection',
      howTo: [
        'Assess battlefield and choose appropriate role',
        'Use mobility to respond to changing threats',
        'Support heavier tanks by flanking enemies',
        'Switch between aggressive and defensive play',
        'Exploit enemy mistakes with quick attacks'
      ]
    },
    weakspots: ['Turret front', 'Lower glacis', 'Side armor', 'Large profile'],
    description: 'Canadian Leopard 2A4M with enhanced armor and mine protection.',
    armor: { front: 200, side: 100, rear: 60 },
    firepower: { damage: 480, penetration: 303, rateOfFire: 6.5 },
    mobility: { speed: 65, reverseSpeed: 30, powerToWeight: 25.5 },
    image: '/tanks/leopard-2a4m.png'
  }
]

export default function WTMWiki() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedTier, setSelectedTier] = useState<string>('all')
  const [selectedType, setSelectedType] = useState<string>('all')
  const [selectedNation, setSelectedNation] = useState<string>('all')
  const [selectedStatus, setSelectedStatus] = useState<string>('all')
  const [selectedTank, setSelectedTank] = useState<Tank | null>(null)

  const filteredTanks = tanksData.filter(tank => {
    const matchesSearch = tank.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesTier = selectedTier === 'all' || tank.tier === selectedTier
    const matchesType = selectedType === 'all' || tank.type === selectedType
    const matchesNation = selectedNation === 'all' || tank.nation === selectedNation
    const matchesStatus = selectedStatus === 'all' || tank.status === selectedStatus
    
    return matchesSearch && matchesTier && matchesType && matchesNation && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Premium': return 'bg-yellow-500'
      case 'Platinum': return 'bg-purple-500'
      case 'Event': return 'bg-blue-500'
      case 'Collectible': return 'bg-green-500'
      case 'Outdated': return 'bg-gray-500'
      case 'Promotional': return 'bg-pink-500'
      default: return 'bg-gray-400'
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Heavy Tank': return 'bg-red-500'
      case 'Medium Tank': return 'bg-green-500'
      case 'Light Tank': return 'bg-blue-500'
      case 'Tank Destroyer': return 'bg-orange-500'
      case 'Self-propelled Gun': return 'bg-purple-500'
      case 'Assault Gun': return 'bg-yellow-500'
      case 'Support Vehicle': return 'bg-cyan-500'
      default: return 'bg-gray-500'
    }
  }

  const getTierColor = (tier: string) => {
    const tierNum = parseInt(tier.match(/\d+/)?.[0] || '0')
    if (tierNum >= 10) return 'bg-gradient-to-r from-red-600 to-red-800'
    if (tierNum >= 8) return 'bg-gradient-to-r from-orange-600 to-orange-800'
    if (tierNum >= 6) return 'bg-gradient-to-r from-blue-600 to-blue-800'
    if (tierNum >= 4) return 'bg-gradient-to-r from-green-600 to-green-800'
    return 'bg-gradient-to-r from-gray-600 to-gray-800'
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white p-4">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-5xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
            WTM WIKI
          </h1>
          <p className="text-gray-300 text-lg mb-2">War Thunder Mobile - Complete Tank Database</p>
          <p className="text-gray-400 text-sm italic">MADE BY HATED FAMILY</p>
        </header>

        <div className="bg-gray-800 rounded-lg p-6 mb-8 shadow-xl">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search tanks..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <Select value={selectedTier} onValueChange={setSelectedTier}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="All Tiers" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="all">All Tiers</SelectItem>
                <SelectItem value="Tier I">Tier I</SelectItem>
                <SelectItem value="Tier II">Tier II</SelectItem>
                <SelectItem value="Tier III">Tier III</SelectItem>
                <SelectItem value="Tier IV">Tier IV</SelectItem>
                <SelectItem value="Tier V">Tier V</SelectItem>
                <SelectItem value="Tier VI">Tier VI</SelectItem>
                <SelectItem value="Tier VII">Tier VII</SelectItem>
                <SelectItem value="Tier VIII">Tier VIII</SelectItem>
                <SelectItem value="Tier IX">Tier IX</SelectItem>
                <SelectItem value="Tier X">Tier X</SelectItem>
                <SelectItem value="Tier XI">Tier XI</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="Heavy Tank">Heavy Tank</SelectItem>
                <SelectItem value="Medium Tank">Medium Tank</SelectItem>
                <SelectItem value="Light Tank">Light Tank</SelectItem>
                <SelectItem value="Tank Destroyer">Tank Destroyer</SelectItem>
                <SelectItem value="Self-propelled Gun">Self-propelled Gun</SelectItem>
                <SelectItem value="Assault Gun">Assault Gun</SelectItem>
                <SelectItem value="Support Vehicle">Support Vehicle</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedNation} onValueChange={setSelectedNation}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="All Nations" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="all">All Nations</SelectItem>
                <SelectItem value="USA">USA</SelectItem>
                <SelectItem value="Germany">Germany</SelectItem>
                <SelectItem value="USSR">USSR</SelectItem>
                <SelectItem value="UK">UK</SelectItem>
                <SelectItem value="France">France</SelectItem>
                <SelectItem value="Japan">Japan</SelectItem>
                <SelectItem value="China">China</SelectItem>
                <SelectItem value="Italy">Italy</SelectItem>
                <SelectItem value="Sweden">Sweden</SelectItem>
                <SelectItem value="Israel">Israel</SelectItem>
                <SelectItem value="Hungary">Hungary</SelectItem>
                <SelectItem value="South Africa">South Africa</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Standard">Standard</SelectItem>
                <SelectItem value="Premium">Premium</SelectItem>
                <SelectItem value="Platinum">Platinum</SelectItem>
                <SelectItem value="Event">Event</SelectItem>
                <SelectItem value="Collectible">Collectible</SelectItem>
                <SelectItem value="Outdated">Outdated</SelectItem>
                <SelectItem value="Promotional">Promotional</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-between items-center">
            <p className="text-gray-300">
              Showing <span className="font-bold text-white">{filteredTanks.length}</span> of{' '}
              <span className="font-bold text-white">{tanksData.length}</span> tanks
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTanks.map((tank) => (
            <Dialog key={tank.id}>
              <DialogTrigger asChild>
                <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-all duration-200 cursor-pointer hover:scale-105 hover:shadow-2xl">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start mb-2">
                      <CardTitle className="text-lg font-bold text-white line-clamp-2">
                        {tank.name}
                      </CardTitle>
                      <div className="flex flex-col gap-1">
                        <Badge className={`${getStatusColor(tank.status)} text-white text-xs`}>
                          {tank.status}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      <Badge className={`${getTierColor(tank.tier)} text-white text-xs`}>
                        {tank.tier}
                      </Badge>
                      <Badge className={`${getTypeColor(tank.type)} text-white text-xs`}>
                        {tank.type}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400 text-sm">Nation:</span>
                        <span className="text-white font-medium">{tank.nation}</span>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Play className="h-4 w-4 text-blue-400" />
                        <span className="text-sm font-medium text-blue-400">{tank.playstyle.name}</span>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-center">
                        <div className="bg-gray-700 rounded p-2">
                          <div className="text-xs text-gray-400">Armor</div>
                          <div className="text-sm font-bold text-green-400">{tank.armor.front}</div>
                        </div>
                        <div className="bg-gray-700 rounded p-2">
                          <div className="text-xs text-gray-400">Damage</div>
                          <div className="text-sm font-bold text-red-400">{tank.firepower.damage}</div>
                        </div>
                        <div className="bg-gray-700 rounded p-2">
                          <div className="text-xs text-gray-400">Speed</div>
                          <div className="text-sm font-bold text-blue-400">{tank.mobility.speed}</div>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="text-xs text-gray-400">Ammunition:</div>
                        <div className="flex flex-wrap gap-1">
                          {tank.ammoType.slice(0, 2).map((ammo, index) => (
                            <Badge key={index} variant="secondary" className="text-xs bg-gray-700 text-gray-300">
                              {ammo}
                            </Badge>
                          ))}
                          {tank.ammoType.length > 2 && (
                            <Badge variant="secondary" className="text-xs bg-gray-700 text-gray-300">
                              +{tank.ammoType.length - 2}
                            </Badge>
                          )}
                        </div>
                      </div>

                      {tank.special && (
                        <div className="text-xs text-yellow-400 bg-yellow-900/20 p-2 rounded border border-yellow-700/30">
                          <Star className="inline h-3 w-3 mr-1" />
                          {tank.special}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </DialogTrigger>
              
              <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto bg-gray-800 text-white">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-bold flex items-center gap-3">
                    {tank.name}
                    <div className="flex gap-2">
                      <Badge className={`${getStatusColor(tank.status)} text-white`}>
                        {tank.status}
                      </Badge>
                      <Badge className={`${getTierColor(tank.tier)} text-white`}>
                        {tank.tier}
                      </Badge>
                      <Badge className={`${getTypeColor(tank.type)} text-white`}>
                        {tank.type}
                      </Badge>
                    </div>
                  </DialogTitle>
                </DialogHeader>
                
                <div className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-semibold mb-2 text-blue-400">Basic Information</h3>
                        <div className="space-y-2 bg-gray-700/50 p-4 rounded">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Nation:</span>
                            <span className="font-medium">{tank.nation}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Type:</span>
                            <span className="font-medium">{tank.type}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Tier:</span>
                            <span className="font-medium">{tank.tier}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Status:</span>
                            <span className="font-medium">{tank.status}</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold mb-2 text-green-400">Armor Characteristics</h3>
                        <div className="space-y-2 bg-gray-700/50 p-4 rounded">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Front Armor:</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-600 rounded-full h-2">
                                <div 
                                  className="bg-green-500 h-2 rounded-full" 
                                  style={{width: `${Math.min((tank.armor.front / 250) * 100, 100)}%`}}
                                />
                              </div>
                              <span className="font-medium">{tank.armor.front}mm</span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Side Armor:</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-600 rounded-full h-2">
                                <div 
                                  className="bg-yellow-500 h-2 rounded-full" 
                                  style={{width: `${Math.min((tank.armor.side / 250) * 100, 100)}%`}}
                                />
                              </div>
                              <span className="font-medium">{tank.armor.side}mm</span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Rear Armor:</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-600 rounded-full h-2">
                                <div 
                                  className="bg-red-500 h-2 rounded-full" 
                                  style={{width: `${Math.min((tank.armor.rear / 250) * 100, 100)}%`}}
                                />
                              </div>
                              <span className="font-medium">{tank.armor.rear}mm</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold mb-2 text-red-400">Firepower</h3>
                        <div className="space-y-2 bg-gray-700/50 p-4 rounded">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Damage:</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-600 rounded-full h-2">
                                <div 
                                  className="bg-red-500 h-2 rounded-full" 
                                  style={{width: `${Math.min((tank.firepower.damage / 1000) * 100, 100)}%`}}
                                />
                              </div>
                              <span className="font-medium">{tank.firepower.damage}</span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Penetration:</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-600 rounded-full h-2">
                                <div 
                                  className="bg-orange-500 h-2 rounded-full" 
                                  style={{width: `${Math.min((tank.firepower.penetration / 500) * 100, 100)}%`}}
                                />
                              </div>
                              <span className="font-medium">{tank.firepower.penetration}mm</span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Rate of Fire:</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-600 rounded-full h-2">
                                <div 
                                  className="bg-purple-500 h-2 rounded-full" 
                                  style={{width: `${Math.min((tank.firepower.rateOfFire / 20) * 100, 100)}%`}}
                                />
                              </div>
                              <span className="font-medium">{tank.firepower.rateOfFire}/min</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-semibold mb-2 text-blue-400">Mobility</h3>
                        <div className="space-y-2 bg-gray-700/50 p-4 rounded">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Forward Speed:</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-600 rounded-full h-2">
                                <div 
                                  className="bg-blue-500 h-2 rounded-full" 
                                  style={{width: `${Math.min((tank.mobility.speed / 100) * 100, 100)}%`}}
                                />
                              </div>
                              <span className="font-medium">{tank.mobility.speed} km/h</span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Reverse Speed:</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-600 rounded-full h-2">
                                <div 
                                  className="bg-cyan-500 h-2 rounded-full" 
                                  style={{width: `${Math.min((tank.mobility.reverseSpeed / 50) * 100, 100)}%`}}
                                />
                              </div>
                              <span className="font-medium">{tank.mobility.reverseSpeed} km/h</span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400">Power-to-Weight:</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-600 rounded-full h-2">
                                <div 
                                  className="bg-green-500 h-2 rounded-full" 
                                  style={{width: `${Math.min((tank.mobility.powerToWeight / 35) * 100, 100)}%`}}
                                />
                              </div>
                              <span className="font-medium">{tank.mobility.powerToWeight} hp/t</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold mb-2 text-yellow-400">Ammunition Types</h3>
                        <div className="flex flex-wrap gap-2 bg-gray-700/50 p-4 rounded">
                          {tank.ammoType.map((ammo, index) => (
                            <Badge key={index} className="bg-yellow-600 text-white">
                              {ammo}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold mb-2 text-purple-400">
                          <Play className="inline h-5 w-5 mr-2" />
                          {tank.playstyle.name}
                        </h3>
                        <div className="space-y-2 bg-gray-700/50 p-4 rounded">
                          <p className="text-purple-300 text-sm mb-3">{tank.playstyle.description}</p>
                          <div className="space-y-2">
                            <div className="text-sm font-medium text-purple-400 mb-2">How to execute:</div>
                            {tank.playstyle.howTo.map((step, index) => (
                              <div key={index} className="flex items-start gap-2 text-purple-300">
                                <ArrowRight className="h-4 w-4 mt-0.5 flex-shrink-0" />
                                <span className="text-sm">{step}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold mb-2 text-red-400">Weakspot Analysis</h3>
                        <div className="space-y-1 bg-gray-700/50 p-4 rounded max-h-48 overflow-y-auto">
                          {tank.weakspots.map((weakspot, index) => (
                            <div key={index} className="flex items-center gap-2 text-red-300">
                              <Target className="h-4 w-4 flex-shrink-0" />
                              <span className="text-sm">{weakspot}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-2 text-gray-300">Technical Description</h3>
                    <p className="text-gray-400 bg-gray-700/50 p-4 rounded leading-relaxed">
                      {tank.description}
                    </p>
                  </div>

                  {tank.special && (
                    <div>
                      <h3 className="text-lg font-semibold mb-2 text-yellow-400">Special Features</h3>
                      <div className="bg-yellow-900/30 border border-yellow-700/50 p-4 rounded">
                        <div className="flex items-center gap-2 text-yellow-300">
                          <Star className="h-5 w-5" />
                          <span>{tank.special}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </DialogContent>
            </Dialog>
          ))}
        </div>

        {filteredTanks.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 text-lg">No tanks found matching your criteria.</div>
            <div className="text-gray-500 text-sm mt-2">Try adjusting your filters or search term.</div>
          </div>
        )}
      </div>
    </div>
  )
}